package com.castpedia.app.ui

import retrofit2.http.GET
import retrofit2.http.Path

data class WikiResponse(
    val title: String,
    val extract: String
)

interface WikipediaApi {
    @GET("page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiResponse
}
