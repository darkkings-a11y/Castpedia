package com.castpedia.app.ui

import retrofit2.http.GET
import retrofit2.http.Path

data class Country(
    val name: CountryName,
    val capital: List<String>?,
    val population: Long
)

data class CountryName(
    val common: String
)

interface RestCountriesApi {
    @GET("name/{name}")
    suspend fun getCountryInfo(@Path("name") name: String): List<Country>
}
