package com.castpedia.app.ui

import retrofit2.http.GET
import retrofit2.http.Query

data class GdeltResponse(
    val articles: List<GdeltArticle>?
)

data class GdeltArticle(
    val title: String,
    val url: String,
    val seendate: String
)

interface GdeltApi {
    @GET("api/v2/doc/doc")
    suspend fun searchEvents(
        @Query("query") query: String,
        @Query("mode") mode: String = "artlist",
        @Query("format") format: String = "json"
    ): GdeltResponse
}
