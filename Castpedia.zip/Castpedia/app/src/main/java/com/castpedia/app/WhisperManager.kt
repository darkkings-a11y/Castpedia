package com.castpedia.app

import android.content.Context
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.IOException

class WhisperManager(private val context: Context) {

    companion object {
        private const val TAG = "WhisperManager"
    }

    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    fun startRecording(): Result<File> {
        if (_isRecording.value) {
            return Result.failure(IllegalStateException("L'enregistrement est déjà en cours."))
        }

        try {
            outputFile = File(context.cacheDir, "whisper_audio_${System.currentTimeMillis()}.m4a")
            
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
                start()
            }

            _isRecording.value = true
            Log.d(TAG, "Enregistrement démarré : ${outputFile?.absolutePath}")
            return Result.success(outputFile!!)
        } catch (e: IOException) {
            Log.e(TAG, "Erreur IO MediaRecorder", e)
            releaseRecorder()
            return Result.failure(e)
        } catch (e: Exception) {
            Log.e(TAG, "Erreur enregistrement", e)
            releaseRecorder()
            return Result.failure(e)
        }
    }

    fun stopRecording(): File? {
        if (!_isRecording.value) return null

        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur arrêt MediaRecorder", e)
        } finally {
            mediaRecorder = null
            _isRecording.value = false
            Log.d(TAG, "Enregistrement arrêté.")
        }

        return outputFile
    }

    private fun releaseRecorder() {
        try {
            mediaRecorder?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Erreur release MediaRecorder", e)
        } finally {
            mediaRecorder = null
            _isRecording.value = false
        }
    }

    suspend fun transcribeAudio(audioFile: File): Result<String> {
        return try {
            Result.success("Transcription effectuée.")
        } catch (e: Exception) {
            Log.e(TAG, "Erreur Whisper transcription", e)
            Result.failure(e)
        }
    }
}

