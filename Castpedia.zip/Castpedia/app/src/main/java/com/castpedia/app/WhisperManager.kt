package com.castpedia.app

import android.content.Context
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.IOException

class WhisperManager(private val context: Context) {

    companion object {
        private const val TAG = "WhisperManager"
    }

    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    /**
     * Démarre l'enregistrement audio proprement pour Whisper,
     * en évitant les micro-coupures et les bips système répétés.
     */
    fun startRecording(): Result<File> {
        if (_isRecording.value) {
            return Result.failure(IllegalStateException("L'enregistrement est déjà en cours."))
        }

        try {
            outputFile = File(context.cacheDir, "whisper_audio_${System.currentTimeMillis()}.m4a")
            
            mediaRecorder = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(outputFile!!.absolutePath)
                prepare()
                start()
            }

            _isRecording.value = true
            Log.d(TAG, "Enregistrement audio démarré avec succès : ${outputFile?.absolutePath}")
            return Result.success(outputFile!!)
        } catch (e: IOException) {
            Log.e(TAG, "Erreur IO lors du démarrage de l'enregistrement", e)
            releaseRecorder()
            return Result.failure(e)
        } catch (e: Exception) {
            Log.e(TAG, "Erreur inattendue lors du démarrage de l'enregistrement", e)
            releaseRecorder()
            return Result.failure(e)
        }
    }

    /**
     * Arrête l'enregistrement audio proprement sans déclencher de bips parasites.
     */
    fun stopRecording(): File? {
        if (!_isRecording.value) return null

        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de l'arrêt du MediaRecorder", e)
        } finally {
            mediaRecorder = null
            _isRecording.value = false
            Log.d(TAG, "Enregistrement audio arrêté.")
        }

        return outputFile
    }

    private fun releaseRecorder() {
        try {
            mediaRecorder?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la libération du MediaRecorder", e)
        } finally {
            mediaRecorder = null
            _isRecording.value = false
        }
    }

    /**
     * Point d'intégration pour envoyer le fichier audio à l'API Whisper / LLM.
     */
    suspend fun transcribeAudio(audioFile: File): Result<String> {
        return try {
            // Intégration de l'appel Whisper réel de ton application ici
            Result.success("Transcription réussie du fichier audio.")
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la transcription Whisper", e)
            Result.failure(e)
        }
    }
}

