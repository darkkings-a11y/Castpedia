package com.castpedia.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import io.github.givimad.whisperjni.WhisperFullParams
import io.github.givimad.whisperjni.WhisperJNI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

object WhisperManager {
    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.3/ggml-small-q8_0.bin"
    var lastError: String? = null
    private var whisperJNI: WhisperJNI? = null
    private var initError: String? = null

    init {
        try {
            WhisperJNI.loadLibrary()
            whisperJNI = WhisperJNI()
        } catch (e: Throwable) {
            // DIAGNOSTIC : on garde la vraie raison de l'échec (Throwable attrape aussi UnsatisfiedLinkError)
            initError = e.toString()
            e.printStackTrace()
        }
    }

    fun getModelFile(context: Context): File {
        return File(context.filesDir, "ggml-small-q8_0.bin")
    }

    fun isModelDownloaded(context: Context): Boolean {
        val file = getModelFile(context)
        return file.exists() && file.length() > 50_000_000
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Boolean): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = getModelFile(context)
            val url = URL(MODEL_URL)
            val connection = url.openConnection()
            val contentLength = connection.contentLength
            
            val input = connection.getInputStream()
            val output = FileOutputStream(file)
            
            val data = ByteArray(8192)
            var total: Long = 0
            var count: Int
            var lastProgress = 0

            while (input.read(data).also { count = it } != -1) {
                total += count.toLong()
                output.write(data, 0, count)
                if (contentLength > 0) {
                    val progress = ((total * 100) / contentLength).toInt()
                    if (progress != lastProgress) {
                        lastProgress = progress
                        onProgress(progress)
                    }
                }
            }
            output.flush()
            output.close()
            input.close()
            true
        } catch (e: Exception) {
            lastError = e.localizedMessage
            false
        }
    }

    fun recordAudio(outputFile: File, onRecordingState: (Boolean) -> Unit): AudioRecord? {
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)

        val audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            channelConfig,
            audioFormat,
            bufferSize
        )

        if (audioRecord.state != AudioRecord.STATE_INITIALIZED) return null

        audioRecord.startRecording()
        onRecordingState(true)

        Thread {
            try {
                FileOutputStream(outputFile).use { fos ->
                    val data = ByteArray(bufferSize)
                    while (audioRecord.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        val read = audioRecord.read(data, 0, data.size)
                        if (read > 0) {
                            fos.write(data, 0, read)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                onRecordingState(false)
            }
        }.start()

        return audioRecord
    }

    suspend fun transcribeAudio(context: Context, pcmFile: File): String = withContext(Dispatchers.IO) {
        try {
            val modelFile = getModelFile(context)

            // DIAGNOSTIC : message précis selon la cause
            if (!modelFile.exists()) {
                return@withContext "Erreur : fichier modèle Whisper introuvable."
            }
            if (whisperJNI == null) {
                return@withContext "Erreur : Whisper non initialisé. Raison : ${initError ?: "inconnue"}"
            }

            val bytes = pcmFile.readBytes()
            if (bytes.isEmpty()) return@withContext ""

            val shortBuffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val samples = FloatArray(shortBuffer.remaining())
            for (i in samples.indices) {
                samples[i] = shortBuffer.get(i) / 32768.0f
            }

            val ctx = whisperJNI!!.init(modelFile.toPath())
            
            val params = WhisperFullParams().apply {
                language = "fr"
                nThreads = 4
                translate = false
            }

            val result = whisperJNI!!.full(ctx, params, samples, samples.size)
            if (result != 0) {
                whisperJNI!!.free(ctx)
                return@withContext "Erreur de transcription (code $result)"
            }

            val numSegments = whisperJNI!!.fullNSegments(ctx)
            val sb = StringBuilder()
            for (i in 0 until numSegments) {
                sb.append(whisperJNI!!.fullGetSegmentText(ctx, i)).append(" ")
            }

            whisperJNI!!.free(ctx)
            return@withContext sb.toString().trim()
        } catch (e: Throwable) {
            e.printStackTrace()
            return@withContext "Erreur de transcription : $e"
        }
    }
}

