
package com.castpedia.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    // Instanciation du lecteur Kokoro avec le contexte de l'activité
    private val kokoroPlayer by lazy { KokoroPlayer(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Vérification et téléchargement au démarrage de Castpedia
        setupKokoroTTS()

        setContent {
            // Affichage de l'interface principale Compose
            MainScreen()
        }
    }

    private fun setupKokoroTTS() {
        if (KokoroManager.areFilesDownloaded(this)) {
            // Fichiers déjà présents, initialisation directe
            initializeKokoroEngine()
        } else {
            // Téléchargement asynchrone depuis GitHub
            lifecycleScope.launch(Dispatchers.IO) {
                val success = KokoroManager.downloadFiles(this@MainActivity) { message, progress ->
                    // Possibilité d'afficher l'avancement si besoin
                }

                if (success) {
                    initializeKokoroEngine()
                }
            }
        }
    }

    private fun initializeKokoroEngine() {
        lifecycleScope.launch(Dispatchers.IO) {
            kokoroPlayer.initialize()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Libération de la mémoire et arrêt audio à la fermeture
        kokoroPlayer.release()
    }
}
