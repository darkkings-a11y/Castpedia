package com.castpedia.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.material3.MaterialTheme

class MainActivity : ComponentActivity() {

    private lateinit var whisperManager: WhisperManager
    private lateinit var llmManager: LlmManager

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Gérer le résultat de la permission du microphone si besoin
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation des gestionnaires
        whisperManager = WhisperManager(applicationContext)
        llmManager = LlmManager()

        // Vérification de la permission d'enregistrement audio pour Whisper
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        setContent {
            MaterialTheme {
                // Appel de MainScreen en passant correctement les gestionnaires requis
                MainScreen(
                    llmManager = llmManager,
                    whisperManager = whisperManager
                )
            }
        }
    }
}

