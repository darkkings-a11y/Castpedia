
package com.castpedia.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.Locale

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Démarrage et vérification des modèles...", false)
    ) }
    var isLoading = remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var statusText = remember { mutableStateOf("Vérification des fichiers...") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecording by remember { mutableStateOf(false) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var generationJob by remember { mutableStateOf<Job?>(null) }

    var currentTopic by remember { mutableStateOf("") }
    var currentRawData by remember { mutableStateOf("") }

    val deviceLanguage = Locale.getDefault().language
    val speechLocale = Locale.getDefault()

    val startListening: () -> Unit = {
        if (!isRecording && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            mainHandler.post {
                try {
                    speechRecognizer?.cancel()
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLocale.toLanguageTag())
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    }
                    speechRecognizer?.startListening(intent)
                } catch (e: Exception) {
                    isRecording = false
                    statusText.value = ""
                }
            }
        }
    }

    val stopEverything: () -> Unit = {
        generationJob?.cancel()
        generationJob = null
        KokoroManager.stopSpeech()
        try {
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
        isSpeaking = false
        isLoading.value = false
        isRecording = false
        statusText.value = ""
    }

    val stopPhrases = listOf(
        "arrête", "arrete", "arrête-toi", "arrete toi", 
        "c'est bon", "ces bon", "laisse tomber", "laisse", 
        "stop", "tais-toi", "tais toi", "suffit", "assez",
        "stop it", "shut up", "para", "basta"
    )

    val continuePhrases = listOf(
        "continue", "poursuis", "et ensuite", "puis", "encore", "oui", "vas-y", "balance"
    )

    val cleanTextForSpeech: (String) -> String = { text ->
        text.replace(Regex("\\*\\*"), "")
            .replace(Regex("\\*"), "")
            .replace(Regex("\\[[0-9\\:\\-\\s]*\\]"), "")
            .replace(Regex("\\[[^\\]]*\\]"), "")
            .replace(Regex("\\([^)]*\\)"), "")
            .trim()
    }

    val initializeAndWelcome: () -> Unit = {
        scope.launch {
            isLoading.value = true
            try {
                withContext(Dispatchers.IO) {
                    // 1. Téléchargement et Init Gemma LLM
                    val gemmaDownloaded = LlmManager.isModelDownloaded(context)
                    if (!gemmaDownloaded) {
                        withContext(Dispatchers.Main) { statusText.value = "Téléchargement du modèle IA (0%)..." }
                        val success = LlmManager.downloadModel(context) { progress ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = "Téléchargement IA : $progress%"
                            }
                        }
                        if (!success) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Téléchargement IA échoué : ${LlmManager.lastError}", false))
                            }
                        }
                    }

                    if (LlmManager.isModelDownloaded(context)) {
                        withContext(Dispatchers.Main) { statusText.value = "Initialisation de l'IA..." }
                        val inference = LlmManager.initialize(context)
                        if (inference == null) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Initialisation IA échouée : ${LlmManager.lastError}", false))
                            }
                        }
                    }

                    // 2. Téléchargement et Init Kokoro ONNX (Voix Haute Fidélité)
                    if (!KokoroManager.isDownloaded(context)) {
                        withContext(Dispatchers.Main) { statusText.value = "Téléchargement Kokoro..." }
                        KokoroManager.downloadModels(context) { msg, pct ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = "$msg $pct%"
                            }
                        }
                    }
                    withContext(Dispatchers.Main) { statusText.value = "Initialisation Kokoro..." }
                    KokoroManager.initialize(context)
                }
            } catch (e: Throwable) {
                Log.e("MainScreen", "Erreur critique d'initialisation", e)
            } finally {
                isLoading.value = false
                statusText.value = ""

                val welcomeText = if (deviceLanguage == "fr") "Bonjour, je suis Castpedia. Que souhaitez-vous savoir ?" else "Hello, I am Castpedia. What would you like to know?"
                messages[0] = ChatMessage("Castpedia", welcomeText, false)
                isSpeaking = true
                KokoroManager.speak(context, welcomeText, 0)
                
                // 1. On libère isSpeaking à 3.5s pour que l'interface reste fluide
                mainHandler.postDelayed({
                    isSpeaking = false
                }, 3500)

                // 2. On retarde l'ouverture du micro à 4800ms pour éviter le chevauchement audio
                mainHandler.postDelayed({
                    startListening()
                }, 7000)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            initializeAndWelcome()
        } else {
            statusText.value = "Permission micro refusée."
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            initializeAndWelcome()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val startGeneration: (String) -> Unit = { prompt ->
        val trimmedPrompt = prompt.trim()

        if (trimmedPrompt.isNotBlank()) {
            val isStopCommand = stopPhrases.any { phrase ->
                trimmedPrompt.equals(phrase, ignoreCase = true) || 
                trimmedPrompt.lowercase().contains(phrase)
            }

            if (isStopCommand) {
                stopEverything()
                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                val stopReply = if (deviceLanguage == "fr") "D'accord, j'arrête tout." else "Okay, stopping everything."
                messages.add(ChatMessage("Castpedia", stopReply, false))
                isSpeaking = true
                KokoroManager.speak(context, stopReply, 0)
                mainHandler.postDelayed({ isSpeaking = false }, 2000)
            } else {
                stopEverything()

                val isContinueCommand = continuePhrases.any { cp ->
                    trimmedPrompt.lowercase().contains(cp)
                }

                val targetTopic: String
                var rawDataToUse: String

                if (isContinueCommand && currentTopic.isNotBlank()) {
                    targetTopic = currentTopic
                    rawDataToUse = currentRawData
                } else {
                    statusText.value = "Analyse de votre demande..."
                    targetTopic = LlmManager.extractTopic(trimmedPrompt)
                    currentTopic = targetTopic
                    rawDataToUse = ""
                }

                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                searchQuery = ""
                isLoading.value = true

                generationJob = scope.launch {
                    if (rawDataToUse.isBlank()) {
                        statusText.value = "Recherche Wikipédia ($targetTopic)..."
                        rawDataToUse = fetchAllApisData(targetTopic, deviceLanguage)
                        currentRawData = rawDataToUse
                    }

                    statusText.value = "Génération du podcast..."
                    val aiMessageIndex = messages.size
                    messages.add(ChatMessage("Castpedia AI", "✍️ Génération en cours...", false))

                    LlmManager.generatePodcastStream(
                        rawData = rawDataToUse,
                        userLanguage = deviceLanguage,
                        onBlockGenerated = { host1, host2, chunkText ->
                            val cleanDisplay = cleanTextForSpeech(chunkText)
                            scope.launch(Dispatchers.Main) {
                                val currentText = messages[aiMessageIndex].text
                                val updatedText = if (currentText.startsWith("✍️")) cleanDisplay else "$currentText\n\n$cleanDisplay"
                                messages[aiMessageIndex] = ChatMessage("Castpedia AI", updatedText, false)
                            }

                            val speechText = cleanTextForSpeech(chunkText)
                            if (speechText.isNotBlank()) {
                                isSpeaking = true
                                KokoroManager.speak(context, speechText, 0)
                            }
                        },
                        onProgressUpdate = { progressText ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = progressText
                            }
                        }
                    )

                    statusText.value = ""
                    isLoading.value = false
                }
            }
        }
    }

    DisposableEffect(context) {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isRecording = true
                statusText.value = "🎤 Écoute en cours..."
            }
            override fun onBeginningOfSpeech() {
                statusText.value = "🎙️ J'écoute..."
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isRecording = false
                statusText.value = "Analyse..."
            }
            override fun onError(error: Int) {
                isRecording = false
                statusText.value = ""
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    mainHandler.postDelayed({ startListening() }, 1500)
                }
            }
            override fun onResults(results: Bundle?) {
                isRecording = false
                statusText.value = ""
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    startGeneration(matches[0])
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer = recognizer

        onDispose {
            try {
                recognizer.destroy()
            } catch (_: Exception) {}
            KokoroManager.release()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Assistant Vocal") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .clickable(enabled = isSpeaking || isLoading.value) {
                    stopEverything()
                    currentTopic = ""
                    currentRawData = ""

                    val ouiText = if (deviceLanguage == "fr") "Oui ?" else "Yes?"
                    isSpeaking = true
                    KokoroManager.speak(context, ouiText, 0)
                    mainHandler.postDelayed({
                        isSpeaking = false
                        startListening()
                    }, 1500)
                }
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { message ->
                        MessageBubble(message = message)
                    }
                    if (isLoading.value || statusText.value.isNotEmpty() || isSpeaking || isRecording) {
                        item {
                            Text(
                                text = if (isRecording) "🎤 Écoute active..." else if (isSpeaking) "🔊 Lecture en cours... (Touchez pour interrompre)" else if (statusText.value.isNotEmpty()) statusText.value else "Traitement...",
                                color = Color(0xFFBB86FC),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { startListening() },
                        modifier = Modifier.background(if (isRecording) Color.Red else Color(0xFF1E1E1E), MaterialTheme.shapes.small)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Micro",
                            tint = if (isRecording) Color.White else Color(0xFFBB86FC)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(if (isRecording) "Parlez..." else "Mode mains libres actif", color = Color.Gray) },
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isLoading.value || isSpeaking || isRecording) {
                        Button(
                            onClick = { stopEverything() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("Stop", color = Color.White)
                        }
                    } else {
                        Button(
                            onClick = { startGeneration(searchQuery) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                        ) {
                            Text("Générer", color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

fun cleanKeyword(input: String): String {
    return input.trim()
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

interface WikipediaApi {
    @GET("w/api.php?action=query&prop=extracts&explaintext=true&format=json&redirects=1")
    suspend fun getPageExtract(
        @Query("titles") title: String
    ): WikiQueryResponse
}

data class WikiQueryResponse(
    val query: WikiQuery?
)

data class WikiQuery(
    val pages: Map<String, WikiPage?>?
)

data class WikiPage(
    val pageid: Int?,
    val title: String?,
    val extract: String?
)

object ApiClient {
    private val userAgentInterceptor = Interceptor { chain ->
        val originalRequest = chain.request()
        val requestWithUserAgent = originalRequest.newBuilder()
            .header("User-Agent", "CastpediaApp/1.0 (contact@castpedia.app)")
            .build()
        chain.proceed(requestWithUserAgent)
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(userAgentInterceptor)
        .build()

    fun <T> createService(baseUrl: String, serviceClass: Class<T>): T {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(serviceClass)
    }
}

suspend fun fetchAllApisData(keyword: String, language: String): String {
    val baseUrl = if (language == "fr") {
        "https://fr.wikipedia.org/"
    } else {
        "https://$language.wikipedia.org/"
    }

    val wikiApi = ApiClient.createService(baseUrl, WikipediaApi::class.java)

    return coroutineScope {
        val wikiDeferred = async(Dispatchers.IO) {
            try { wikiApi.getPageExtract(keyword) } catch (e: Exception) { null }
        }

        val response = wikiDeferred.await()
        val pages = response?.query?.pages?.values
        val page = pages?.firstOrNull()

        val sb = StringBuilder()
        sb.append("Sujet recherché / Topic: $keyword\n\n")

        if (page?.extract != null) {
            sb.append("CONTENU WIKIPÉDIA (Structure H2/H3 et sections chronologiques) :\n${page.extract}\n\n")
        } else {
            sb.append("Aucune information factuelle trouvée pour $keyword. Ne rien inventer.\n\n")
        }

        sb.toString()
    }
}
