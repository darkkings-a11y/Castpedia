package com.castpedia.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.Locale

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Démarrage et vérification des modèles...", false)
    ) }
    var isLoading = remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var statusText = remember { mutableStateOf("Vérification des fichiers...") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecording by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsInitialized by remember { mutableStateOf(false) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var isFirstSpeechBlock = remember { true }

    // Détection automatique de la langue du téléphone
    val deviceLanguage = Locale.getDefault().language
    val speechLocale = Locale.getDefault()

    val startListening: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            mainHandler.post {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, speechLocale.toString())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                try {
                    speechRecognizer?.startListening(intent)
                } catch (e: Exception) {
                    isRecording = false
                    statusText.value = "Erreur micro."
                }
            }
        }
    }

    val stopEverything: () -> Unit = {
        tts?.stop() // Coupe net le TTS en cours
        speechRecognizer?.cancel()
        isSpeaking = false
        isLoading.value = false
        isRecording = false
        statusText.value = ""
    }

    val stopPhrases = listOf(
        "arrête", "arrete", "arrête-toi", "arrete toi", 
        "c'est bon", "ces bon", "laisse tomber", "laisse", 
        "stop", "tais-toi", "tais toi", "suffit", "assez",
        "stop it", "shut up", "para", "basta"
    )

    val cleanTextForSpeech: (String) -> String = { text ->
        text.replace(Regex("\\*\\*"), "")
            .replace(Regex("\\*"), "")
            .replace(Regex("\\[[0-9\\:\\-\\s]*\\]"), "")
            .replace(Regex("\\[[^\\]]*\\]"), "")
            .replace(Regex("\\([^)]*\\)"), "")
            .trim()
    }

    val initializeAndWelcome: () -> Unit = {
        scope.launch {
            isLoading.value = true
            try {
                withContext(Dispatchers.IO) {
                    val gemmaDownloaded = LlmManager.isModelDownloaded(context)
                    if (!gemmaDownloaded) {
                        withContext(Dispatchers.Main) { statusText.value = "Téléchargement du modèle (0%)..." }
                        val success = LlmManager.downloadModel(context) { progress ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = "Téléchargement : $progress%"
                            }
                        }
                        if (!success) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Téléchargement échoué : ${LlmManager.lastError}", false))
                            }
                        }
                    }

                    if (LlmManager.isModelDownloaded(context)) {
                        withContext(Dispatchers.Main) { statusText.value = "Initialisation de l'IA..." }
                        val inference = LlmManager.initialize(context)
                        if (inference == null) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Initialisation IA échouée : ${LlmManager.lastError}", false))
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e("MainScreen", "Erreur critique d'initialisation", e)
            } finally {
                isLoading.value = false
                statusText.value = ""

                val welcomeText = if (deviceLanguage == "fr") "Bonjour, je suis Castpedia. Que souhaitez-vous savoir ?" else "Hello, I am Castpedia. What would you like to know?"
                messages[0] = ChatMessage("Castpedia", welcomeText, false)
                tts?.speak(welcomeText, TextToSpeech.QUEUE_FLUSH, null, "WelcomeUtterance")
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            initializeAndWelcome()
        } else {
            statusText.value = "Permission micro refusée."
        }
    }

    LaunchedEffect(ttsInitialized) {
        if (ttsInitialized) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                initializeAndWelcome()
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    val startGeneration: (String) -> Unit = { prompt ->
        val trimmedPrompt = prompt.trim()

        if (trimmedPrompt.isNotBlank()) {
            val isStopCommand = stopPhrases.any { phrase ->
                trimmedPrompt.equals(phrase, ignoreCase = true) || 
                trimmedPrompt.lowercase().contains(phrase)
            }

            if (isStopCommand) {
                stopEverything()
                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                val stopReply = if (deviceLanguage == "fr") "D'accord, j'arrête tout." else "Okay, stopping everything."
                messages.add(ChatMessage("Castpedia", stopReply, false))
                tts?.setPitch(1.0f)
                tts?.speak(stopReply, TextToSpeech.QUEUE_FLUSH, null, "StopUtterance")
            } else {
                // Stoppe proprement toute lecture précédente et vide la file d'attente pour basculer sur le nouveau sujet
                stopEverything()

                val cleanedKeyword = cleanKeyword(trimmedPrompt)
                
                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                searchQuery = ""
                isLoading.value = true
                isFirstSpeechBlock = true

                scope.launch {
                    statusText.value = "Recherche Wikipédia ($cleanedKeyword)..."
                    val rawData = fetchAllApisData(cleanedKeyword, deviceLanguage)
                    
                    statusText.value = "Génération du podcast..."
                    val aiMessageIndex = messages.size
                    messages.add(ChatMessage("Castpedia AI", "✍️ Génération en cours...", false))

                    LlmManager.generatePodcastStream(
                        rawData = rawData,
                        userLanguage = deviceLanguage,
                        onBlockGenerated = { host1, host2, chunkText ->
                            val cleanDisplay = cleanTextForSpeech(chunkText)
                            scope.launch(Dispatchers.Main) {
                                val currentText = messages[aiMessageIndex].text
                                val updatedText = if (currentText.startsWith("✍️")) cleanDisplay else "$currentText\n\n$cleanDisplay"
                                messages[aiMessageIndex] = ChatMessage("Castpedia AI", updatedText, false)
                            }

                            val lines = chunkText.split("\n")
                            for (line in lines) {
                                val trimmedLine = line.trim()
                                if (trimmedLine.isBlank()) continue
                                if (trimmedLine.lowercase().contains("bien sûr") || trimmedLine.lowercase().contains("voici") || trimmedLine.lowercase().contains("sure")) continue

                                if (trimmedLine.contains(":")) {
                                    val parts = trimmedLine.split(":", limit = 2)
                                    val speaker = cleanTextForSpeech(parts[0])
                                    val speechText = cleanTextForSpeech(parts[1])

                                    if (speechText.isNotBlank()) {
                                        val pitch = if (speaker == host1) 0.85f else 1.25f
                                        val rate = if (speaker == host1) 1.0f else 1.05f
                                        tts?.setPitch(pitch)
                                        tts?.setSpeechRate(rate)

                                        val queueMode = if (isFirstSpeechBlock) {
                                            isFirstSpeechBlock = false
                                            TextToSpeech.QUEUE_FLUSH
                                        } else {
                                            TextToSpeech.QUEUE_ADD
                                        }
                                        tts?.speak(speechText, queueMode, null, "PodcastLine")
                                    }
                                } else {
                                    val cleanText = cleanTextForSpeech(trimmedLine)
                                    if (cleanText.isNotBlank()) {
                                        tts?.setPitch(1.0f)
                                        tts?.setSpeechRate(1.0f)
                                        val queueMode = if (isFirstSpeechBlock) {
                                            isFirstSpeechBlock = false
                                            TextToSpeech.QUEUE_FLUSH
                                        } else {
                                            TextToSpeech.QUEUE_ADD
                                        }
                                        tts?.speak(cleanText, queueMode, null, "PodcastLine")
                                    }
                                }
                            }
                        },
                        onProgressUpdate = { progressText ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = progressText
                            }
                        }
                    )

                    statusText.value = ""
                    isLoading.value = false
                }
            }
        }
    }

    DisposableEffect(context) {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isRecording = true
                statusText.value = "🎤 Écoute en cours..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isRecording = false
                statusText.value = "Analyse..."
            }
            override fun onError(error: Int) {
                isRecording = false
                statusText.value = ""
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    startListening()
                }
            }
            override fun onResults(results: Bundle?) {
                isRecording = false
                statusText.value = ""
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    startGeneration(matches[0])
                } else {
                    startListening()
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer = recognizer

        var engineInstance: TextToSpeech? = null
        engineInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineInstance?.language = speechLocale
                ttsInitialized = true
            }
        }

        engineInstance?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
            }
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "WelcomeUtterance") {
                    isSpeaking = false
                    mainHandler.post {
                        startListening()
                    }
                } else if (utteranceId == "InterruptUtterance") {
                    isSpeaking = false
                    mainHandler.post {
                        startListening()
                    }
                } else if (utteranceId == "PodcastLine") {
                    isSpeaking = false
                }
            }
            override fun onError(utteranceId: String?) {
                isSpeaking = false
            }
        })

        tts = engineInstance

        onDispose {
            recognizer.destroy()
            engineInstance?.stop()
            engineInstance?.shutdown()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Assistant Vocal") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .clickable(enabled = isSpeaking || isLoading.value) {
                    stopEverything()
                    tts?.setPitch(1.0f)
                    tts?.setSpeechRate(1.0f)
                    val ouiText = if (deviceLanguage == "fr") "Oui ?" else "Yes?"
                    tts?.speak(ouiText, TextToSpeech.QUEUE_FLUSH, null, "InterruptUtterance")
                }
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { message ->
                        MessageBubble(message = message)
                    }
                    if (isLoading.value || statusText.value.isNotEmpty() || isSpeaking || isRecording) {
                        item {
                            Text(
                                text = if (isRecording) "🎤 Écoute active..." else if (isSpeaking) "🔊 Lecture en cours... (Touchez pour interrompre)" else if (statusText.value.isNotEmpty()) statusText.value else "Traitement...",
                                color = Color(0xFFBB86FC),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { startListening() },
                        modifier = Modifier.background(if (isRecording) Color.Red else Color(0xFF1E1E1E), MaterialTheme.shapes.small)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Micro",
                            tint = if (isRecording) Color.White else Color(0xFFBB86FC)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(if (isRecording) "Parlez..." else "Mode mains libres actif", color = Color.Gray) },
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFFBB86FC),
                            unfocusedBorderColor = Color.Gray
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    if (isLoading.value || isSpeaking || isRecording) {
                        Button(
                            onClick = { stopEverything() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                        ) {
                            Text("Stop", color = Color.White)
                        }
                    } else {
                        Button(
                            onClick = { startGeneration(searchQuery) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                        ) {
                            Text("Générer", color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

fun cleanKeyword(input: String): String {
    var cleaned = input.trim().lowercase()
    
    val phrasesToRemove = listOf(
        "est ce que tu peux me parler de la ", "est-ce que tu peux me parler de la ",
        "est ce que tu peux me parler d'", "est-ce que tu peux me parler d'",
        "est ce que tu peux me parler de ", "est-ce que tu peux me parler de ",
        "tu peux me parler de la ", "tu peux me parler d'", "tu peux me parler de ",
        "parle moi de la ", "parle-moi de la ", "parle moi d'", "parle-moi d'",
        "parle moi de ", "parle-moi de ",
        "c'est quoi ", "qui est ", "cherche ", "info sur ", "informations sur ",
        "est ce que tu connais ", "est-ce que tu connais ", "tu connais ",
        "dis moi tout sur ", "dis-moi tout sur ", "dis moi qui est ", "dis-moi qui est ",
        "peux tu me parler de la ", "peux-tu me parler de la ",
        "peux tu me parler de ", "peux-tu me parler de ",
        "can you tell me about ", "tell me about ", "what is ", "who is "
    )
    
    for (phrase in phrasesToRemove) {
        if (cleaned.startsWith(phrase)) {
            cleaned = cleaned.substring(phrase.length).trim()
            break
        }
    }
    
    return cleaned
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

interface WikipediaApi {
    @GET("page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiResponse
}

interface EnglishWikipediaApi {
    @GET("page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiResponse
}

data class WikiResponse(
    val extract: String?
)

object ApiClient {
    fun <T> createService(baseUrl: String, serviceClass: Class<T>): T {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(serviceClass)
    }
}

suspend fun fetchAllApisData(keyword: String, language: String): String {
    val baseUrl = if (language == "fr") {
        "https://fr.wikipedia.org/api/rest_v1/"
    } else {
        "https://$language.wikipedia.org/api/rest_v1/"
    }

    val wikiApi = ApiClient.createService(baseUrl, WikipediaApi::class.java)

    return coroutineScope {
        val wikiDeferred = async(Dispatchers.IO) {
            try { wikiApi.getSummary(keyword) } catch (e: Exception) { null }
        }

        val wiki = wikiDeferred.await()

        val sb = StringBuilder()
        sb.append("Sujet recherché / Topic: $keyword\n\n")

        if (wiki?.extract != null) {
            sb.append("Wikipédia : ${wiki.extract}\n\n")
        } else {
            sb.append("Informations générales sur $keyword.\n\n")
        }

        sb.toString()
    }
}

