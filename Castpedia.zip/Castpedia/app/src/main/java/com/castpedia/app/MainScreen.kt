package com.castpedia.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Bonjour ! Tape le nom d'un sujet pour lancer l'exploration et générer ton podcast.", false)
    ) }
    var isLoading by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    // Initialisation du LLM local au démarrage
    LaunchedEffect(Unit) {
        LlmManager.initialize(context)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Local AI & APIs") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message = message)
                }
                if (isLoading) {
                    item {
                        Text(
                            "Extraction des données et reformulation par Gemma...",
                            color = Color.Gray,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Ex: Louis XIV, Japon, Einstein...", color = Color.Gray) },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        if (searchQuery.isNotBlank() && !isLoading) {
                            val keyword = searchQuery
                            messages.add(ChatMessage("Moi", keyword, true))
                            searchQuery = ""
                            isLoading = true

                            coroutineScope.launch {
                                // 1. Récupération des données brutes en français
                                val rawData = fetchAllApisData(keyword)
                                
                                // 2. Transformation en script de podcast par Gemma 3 1B
                                val podcastScript = LlmManager.generatePodcastScript(rawData)

                                messages.add(ChatMessage("Castpedia AI", podcastScript, false))
                                isLoading = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Générer", color = Color.Black)
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

suspend fun fetchAllApisData(keyword: String): String {
    val wikiApi = ApiClient.createService("https://fr.wikipedia.org/api/rest_v1/", WikipediaApi::class.java)
    val wikidataApi = ApiClient.createService("https://www.wikidata.org/w/", WikidataApi::class.java)
    val countriesApi = ApiClient.createService("https://restcountries.com/v3.1/", RestCountriesApi::class.java)
    val gdeltApi = ApiClient.createService("https://api.gdeltproject.org/", GdeltApi::class.java)

    return coroutineScope {
        val wikiDeferred = async { runCatching { wikiApi.getSummary(keyword) } }
        val wikidataDeferred = async { runCatching { wikidataApi.searchEntity(keyword) } }
        val countryDeferred = async { runCatching { countriesApi.getCountryInfo(keyword) } }
        val gdeltDeferred = async { runCatching { gdeltApi.searchEvents(keyword) } }

        val wiki = wikiDeferred.await().getOrNull()
        val wikidata = wikidataDeferred.await().getOrNull()
        val country = countryDeferred.await().getOrNull()
        val gdelt = gdeltDeferred.await().getOrNull()

        val sb = StringBuilder()
        sb.append("Sujet recherché : $keyword\n\n")

        if (wiki != null) {
            sb.append("Wikipédia : ${wiki.extract}\n\n")
        }
        if (country != null && country.isNotEmpty()) {
            val c = country.first()
            sb.append("Pays : ${c.name.common} (Capitale : ${c.capital?.joinToString() ?: "N/A"}, Population : ${c.population})\n\n")
        }
        if (wikidata != null && !wikidata.search.isNullOrEmpty()) {
            val entity = wikidata.search.first()
            sb.append("Wikidata : ${entity.label} - ${entity.description}\n\n")
        }
        if (gdelt != null && !gdelt.articles.isNullOrEmpty()) {
            sb.append("Actualités : ${gdelt.articles.size} articles récents trouvés.\n")
        }

        sb.toString()
    }
}

