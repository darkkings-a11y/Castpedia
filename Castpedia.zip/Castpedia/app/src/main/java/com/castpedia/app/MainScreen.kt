package com.castpedia.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.Locale

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Bonjour ! Vérification des modèles IA...", false)
    ) }
    var isLoading by remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecording by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    // Fonction pour tout stopper net (voix, chargement, statut)
    val stopEverything: () -> Unit = {
        tts?.stop()
        isSpeaking = false
        isLoading = false
        statusText = ""
    }

    // Liste intelligente des expressions d'arrêt (insensible à la casse)
    val stopPhrases = listOf(
        "arrête", "arrete", "arrête-toi", "arrete toi", 
        "c'est bon", "ces bon", "laisse tomber", "laisse", 
        "stop", "tais-toi", "tais toi", "suffit", "assez"
    )

    // Fonction centralisée de génération
    val startGeneration: (String) -> Unit = { prompt ->
        val trimmedPrompt = prompt.trim()

        if (trimmedPrompt.isNotBlank()) {
            // 1. Vérification si l'utilisateur veut stopper l'application vocalement
            val isStopCommand = stopPhrases.any { phrase ->
                trimmedPrompt.equals(phrase, ignoreCase = true) || 
                trimmedPrompt.lowercase().contains(phrase)
            }

            if (isStopCommand) {
                stopEverything()
                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                messages.add(ChatMessage("Castpedia", "D'accord, j'arrête tout.", false))
            } else {
                // 2. Sinon, comportement normal : Lancement de la recherche et du podcast
                if (!isLoading) {
                    val cleanedKeyword = cleanKeyword(trimmedPrompt)
                    
                    messages.add(ChatMessage("Moi", trimmedPrompt, true))
                    searchQuery = ""
                    isLoading = true

                    coroutineScope.launch {
                        statusText = "Recherche Wikipédia..."
                        val rawData = fetchAllApisData(cleanedKeyword)
                        
                        statusText = ""
                        val aiMessageIndex = messages.size
                        messages.add(ChatMessage("Castpedia AI", "✍️ Génération du premier bloc...", false))
                        
                        var lastReadLength = 0

                        LlmManager.generatePodcastScript(rawData) { currentScript ->
                            messages[aiMessageIndex] = ChatMessage("Castpedia AI", currentScript, false)

                            if (currentScript.length > lastReadLength) {
                                val rawChunk = currentScript.substring(lastReadLength)
                                
                                val cleanChunk = rawChunk
                                    .replace(Regex("[#*_`~]"), "")
                                    .replace(Regex("\\([^)]*\\)"), "")
                                    .replace(Regex("\\[[^\\]]*\\]"), "")
                                    .trim()

                                lastReadLength = currentScript.length

                                if (cleanChunk.isNotBlank()) {
                                    tts?.speak(cleanChunk, TextToSpeech.QUEUE_ADD, null, "CastpediaUtterance")
                                }
                            }
                        }

                        isLoading = false
                    }
                }
            }
        }
    }

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        isRecording = false
        statusText = ""
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                val spokenText = matches[0]
                // Appel direct et propre, sans label buggé
                startGeneration(spokenText)
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            isRecording = true
            statusText = "🎤 Écoute en cours... Parlez !"
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRENCH.toString())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez maintenant...")
            }
            try {
                speechRecognizerLauncher.launch(intent)
            } catch (e: Exception) {
                isRecording = false
                statusText = "Erreur de lancement du micro."
            }
        }
    }
    
    DisposableEffect(context) {
        var engineInstance: TextToSpeech? = null
        engineInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineInstance?.language = Locale.FRENCH
            }
        }

        engineInstance?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
            }
            override fun onDone(utteranceId: String?) {
                isSpeaking = false
            }
            override fun onError(utteranceId: String?) {
                isSpeaking = false
            }
        })

        tts = engineInstance
        onDispose {
            engineInstance?.stop()
            engineInstance?.shutdown()
        }
    }

    LaunchedEffect(Unit) {
        isLoading = true

        val gemmaDownloaded = withContext(Dispatchers.IO) { LlmManager.isModelDownloaded(context) }
        if (!gemmaDownloaded) {
            statusText = "Téléchargement de Gemma (0%)..."
            LlmManager.downloadModel(context) { progress ->
                statusText = "Téléchargement de Gemma : $progress%"
            }
        }
        val engine = withContext(Dispatchers.IO) { LlmManager.initialize(context) }

        if (engine != null) {
            messages.add(ChatMessage("Castpedia", "Modèle Gemma & IA prêts à l'emploi !", false))
        } else {
            messages.add(ChatMessage("Castpedia", "Prêt (certains modèles manquent ou erreur d'init).", false))
        }

        isLoading = false
        statusText = ""
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Local AI & APIs") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message = message)
                }
                if (isLoading || statusText.isNotEmpty() || isSpeaking) {
                    item {
                        Text(
                            text = if (isSpeaking) "🔊 Lecture en cours..." else if (statusText.isNotEmpty()) statusText else "Traitement en cours...",
                            color = Color(0xFFBB86FC),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                            isRecording = true
                            statusText = "🎤 Écoute en cours... Parlez !"
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRENCH.toString())
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Parlez maintenant...")
                            }
                            try {
                                speechRecognizerLauncher.launch(intent)
                            } catch (e: Exception) {
                                isRecording = false
                                statusText = "Erreur de lancement du micro."
                            }
                        } else {
                            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    modifier = Modifier.background(if (isRecording) Color.Red else Color(0xFF1E1E1E), MaterialTheme.shapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Micro",
                        tint = if (isRecording) Color.White else Color(0xFFBB86FC)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (isRecording) "En écoute..." else "Ex: Japon, Louis XIV...", color = Color.Gray) },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                if (isLoading || isSpeaking) {
                    Button(
                        onClick = { stopEverything() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Stop", color = Color.White)
                    }
                } else {
                    Button(
                        onClick = { startGeneration(searchQuery) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                    ) {
                        Text("Générer", color = Color.Black)
                    }
                }
            }
        }
    }
}

fun cleanKeyword(input: String): String {
    val lower = input.trim()
    val prefixes = listOf("parle moi de ", "parle-moi de ", "c'est quoi ", "qui est ", "cherche ", "info sur ")
    for (prefix in prefixes) {
        if (lower.startsWith(prefix, ignoreCase = true)) {
            return lower.substring(prefix.length).trim()
        }
    }
    return input.trim()
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

interface WikipediaApi {
    @GET("page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiResponse
}

data class WikiResponse(
    val extract: String?
)

object ApiClient {
    fun <T> createService(baseUrl: String, serviceClass: Class<T>): T {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(serviceClass)
    }
}

suspend fun fetchAllApisData(keyword: String): String {
    val wikiApi = ApiClient.createService("https://fr.wikipedia.org/api/rest_v1/", WikipediaApi::class.java)

    return coroutineScope {
        val wikiDeferred = async(Dispatchers.IO) {
            try { wikiApi.getSummary(keyword) } catch (e: Exception) { null }
        }

        val wiki = wikiDeferred.await()

        val sb = StringBuilder()
        sb.append("Sujet recherché : $keyword\n\n")

        if (wiki?.extract != null) {
            sb.append("Wikipédia : ${wiki.extract}\n\n")
        } else {
            sb.append("Informations générales sur $keyword.\n\n")
        }

        sb.toString()
    }
}

