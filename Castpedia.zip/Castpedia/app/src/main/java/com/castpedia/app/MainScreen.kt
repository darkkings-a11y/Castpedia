
package com.castpedia.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    llmManager: LlmManager,
    whisperManager: WhisperManager
) {
    val coroutineScope = rememberCoroutineScope()
    var podcastScript by remember { mutableStateOf("Bienvenue dans Castpedia. Sélectionnez un sujet ou lancez la génération pour écouter votre épisode.") }
    var isLoading by remember { mutableStateOf(false) }
    val isRecording by whisperManager.isRecording.collectAsState()

    // Animation fluide et stable pour la ligne du bas (supprime les sauts brusques)
    val infiniteTransition = rememberInfiniteTransition(label = "bottom_line_animation")
    val lineAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "lineAlpha"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia Studio") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        bottomBar = {
            // Ligne du bas stabilisée avec indicateur visuel d'enregistrement/activité
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(
                        if (isRecording) MaterialTheme.colorScheme.error.copy(alpha = lineAlpha)
                        else MaterialTheme.colorScheme.primary.copy(alpha = lineAlpha)
                    )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (isRecording) {
                        whisperManager.stopRecording()
                    } else {
                        whisperManager.startRecording()
                    }
                },
                containerColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Refresh else Icons.Default.Mic,
                    contentDescription = if (isRecording) "Arrêter l'enregistrement" else "Démarrer l'enregistrement"
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Génération du Podcast",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                isLoading = true
                                val result = llmManager.generatePodcastScript(
                                    topic = "Intelligence Artificielle et Exploration Spatiale",
                                    wikiSummary = "L'IA transforme l'exploration spatiale moderne...",
                                    wikidataInfo = "QID: Q11660 - Exploration spatiale",
                                    newsContext = "Dernières avancées des rovers martiens autonomes."
                                )
                                result.onSuccess { script ->
                                    podcastScript = script
                                }.onFailure { error ->
                                    podcastScript = "Erreur lors de la génération : ${error.localizedMessage}"
                                }
                                isLoading = false
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isLoading) "Génération en cours..." else "Générer le script du Podcast")
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Script de l'Épisode",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = podcastScript,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
