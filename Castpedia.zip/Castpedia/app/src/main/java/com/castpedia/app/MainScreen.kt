    LaunchedEffect(Unit) {
        if (!LlmManager.isModelDownloaded(context)) {
            isLoading = true
            statusText = "Téléchargement du modèle IA (0%)..."
            val success = LlmManager.downloadModel(context) { progress ->
                statusText = "Téléchargement du modèle IA : $progress%"
            }
            if (success) {
                statusText = "Initialisation du moteur..."
                LlmManager.initialize(context)
                messages.add(ChatMessage("Castpedia", "Modèle IA téléchargé et prêt !", false))
            } else {
                messages.add(ChatMessage("Castpedia", "Échec téléchargement : ${LlmManager.lastError}", false))
            }
            isLoading = false
            statusText = ""
        } else {
            LlmManager.initialize(context)
        }
    }

