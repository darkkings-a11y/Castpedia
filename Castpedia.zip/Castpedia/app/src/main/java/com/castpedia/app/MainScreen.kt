
package com.castpedia.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Structure d'un message du podcast
data class PodcastMessage(
    val id: String,
    val speaker: String,
    val text: String,
    val speakerColor: Color,
    val isUser: Boolean = false,
    val highlightedText: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val messages = remember {
        listOf(
            PodcastMessage("1", "Vous", "Comment fonctionne la génération multi-voix ?", Color.Gray, isUser = true),
            PodcastMessage("2", "Voix A", "Bonjour ! Castpedia génère une synthèse vocale dynamique à plusieurs voix.", Color(0xFF00E5FF)),
            PodcastMessage("3", "Voix B", "Et chaque voix possède sa propre identité visuelle et sonore.", Color(0xFFE040FB), highlightedText = "identité visuelle et sonore.")
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.Menu, contentDescription = "Menu historique")
                    }
                },
                actions = {
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.Share, contentDescription = "Exporter")
                    }
                    IconButton(onClick = { }) {
                        Icon(Icons.Default.Settings, contentDescription = "Paramètres")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        bottomBar = {
            BottomControls()
        },
        containerColor = Color(0xFF121212)
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                MessageBubble(message = msg)
            }
        }
    }
}

@Composable
fun MessageBubble(message: PodcastMessage) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (message.isUser) Alignment.End else Alignment.Start
    ) {
        if (!message.isUser) {
            Text(
                text = message.speaker,
                color = message.speakerColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
            )
        }
        
        Box(
            modifier = Modifier
                .background(
                    color = if (message.isUser) Color(0xFF1E293B) else Color(0xFF1F1F1F),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(14.dp)
        ) {
            Text(
                text = message.text,
                color = Color.White,
                fontSize = 15.sp
            )
        }
    }
}

@Composable
fun BottomControls() {
    Surface(
        color = Color(0xFF181818),
        tonalElevation = 8.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = { }) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Jouer", tint = Color.White)
                }
                Slider(
                    value = 0.3f,
                    onValueChange = {},
                    modifier = Modifier.weight(1f)
                )
                Text("01:23 / 03:45", color = Color.Gray, fontSize = 12.sp)
            }

            // Bouton principal remplacé par une icône standard garantie sans erreur
            FloatingActionButton(
                onClick = { },
                shape = CircleShape,
                containerColor = Color(0xFF00E5FF),
                contentColor = Color.Black
            ) {
                Icon(Icons.Default.Send, contentDescription = "Envoyer", modifier = Modifier.size(26.dp))
            }
        }
    }
}
