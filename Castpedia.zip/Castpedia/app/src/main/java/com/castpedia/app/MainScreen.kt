package com.castpedia.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.Locale

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Démarrage et vérification des modèles...", false)
    ) }
    var isLoading = remember { mutableStateOf(false) }
    var isSpeaking by remember { mutableStateOf(false) }
    var statusText = remember { mutableStateOf("Vérification des fichiers...") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecording by remember { mutableStateOf(false) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsInitialized by remember { mutableStateOf(false) }
    var speechRecognizer by remember { mutableStateOf<SpeechRecognizer?>(null) }
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    var host1Name by remember { mutableStateOf<String?>(null) }
    var host2Name by remember { mutableStateOf<String?>(null) }

    val startListening: () -> Unit = {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            mainHandler.post {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.FRENCH.toString())
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                try {
                    speechRecognizer?.startListening(intent)
                } catch (e: Exception) {
                    isRecording = false
                    statusText.value = "Erreur micro."
                }
            }
        }
    }

    val stopEverything: () -> Unit = {
        tts?.stop()
        speechRecognizer?.cancel()
        isSpeaking = false
        isLoading.value = false
        isRecording = false
        statusText.value = ""
    }

    val stopPhrases = listOf(
        "arrête", "arrete", "arrête-toi", "arrete toi", 
        "c'est bon", "ces bon", "laisse tomber", "laisse", 
        "stop", "tais-toi", "tais toi", "suffit", "assez"
    )

    val cleanTextForSpeech: (String) -> String = { text ->
        text.replace(Regex("\\*\\*"), "")
            .replace(Regex("\\*"), "")
            .replace(Regex("\\[[0-9\\:\\-\\s]*\\]"), "")
            .replace(Regex("\\[[^\\]]*\\]"), "")
            .replace(Regex("\\([^)]*\\)"), "")
            .trim()
    }

    val startGeneration: (String) -> Unit = { prompt ->
        val trimmedPrompt = prompt.trim()

        if (trimmedPrompt.isNotBlank()) {
            val isStopCommand = stopPhrases.any { phrase ->
                trimmedPrompt.equals(phrase, ignoreCase = true) || 
                trimmedPrompt.lowercase().contains(phrase)
            }

            if (isStopCommand) {
                stopEverything()
                messages.add(ChatMessage("Moi", trimmedPrompt, true))
                messages.add(ChatMessage("Castpedia", "D'accord, j'arrête tout.", false))
                tts?.setPitch(1.0f)
                tts?.speak("D'accord.", TextToSpeech.QUEUE_FLUSH, null, "StopUtterance")
            } else {
                if (!isLoading.value) {
                    speechRecognizer?.cancel()
                    isRecording = false

                    val cleanedKeyword = cleanKeyword(trimmedPrompt)
                    
                    messages.add(ChatMessage("Moi", trimmedPrompt, true))
                    searchQuery = ""
                    isLoading.value = true
                    host1Name = null
                    host2Name = null

                    scope.launch {
                        statusText.value = "Recherche Wikipédia..."
                        val rawData = fetchAllApisData(cleanedKeyword)
                        
                        statusText.value = "Génération du podcast (20 blocs)..."
                        val aiMessageIndex = messages.size
                        messages.add(ChatMessage("Castpedia AI", "✍️ Génération en cours...", false))

                        val fullScript = LlmManager.generatePodcastScript(rawData) { currentProgressText ->
                            val cleanDisplay = cleanTextForSpeech(currentProgressText)
                            messages[aiMessageIndex] = ChatMessage("Castpedia AI", cleanDisplay, false)
                        }
                        
                        val cleanScriptDisplay = cleanTextForSpeech(fullScript)
                        messages[aiMessageIndex] = ChatMessage("Castpedia AI", cleanScriptDisplay, false)

                        val lines = fullScript.split("\n")
                        val speechItems = mutableListOf<Triple<String, Float, Float>>()

                        for (line in lines) {
                            val trimmedLine = line.trim()
                            if (trimmedLine.isBlank()) continue
                            if (trimmedLine.startsWith("Bien sûr") || trimmedLine.startsWith("Voici")) continue

                            if (trimmedLine.contains(":")) {
                                val parts = trimmedLine.split(":", limit = 2)
                                val speaker = cleanTextForSpeech(parts[0])
                                val speechText = cleanTextForSpeech(parts[1])

                                if (speechText.isNotBlank()) {
                                    if (host1Name == null) {
                                        host1Name = speaker
                                    } else if (host2Name == null && speaker != host1Name) {
                                        host2Name = speaker
                                    }

                                    val pitch = if (speaker == host1Name) 0.85f else 1.25f
                                    val rate = if (speaker == host1Name) 1.0f else 1.05f
                                    speechItems.add(Triple(speechText, pitch, rate))
                                }
                            } else {
                                val cleanText = cleanTextForSpeech(trimmedLine)
                                if (cleanText.isNotBlank()) {
                                    speechItems.add(Triple(cleanText, 1.0f, 1.0f))
                                }
                            }
                        }

                        for ((index, item) in speechItems.withIndex()) {
                            val (text, pitch, rate) = item
                            tts?.setPitch(pitch)
                            tts?.setSpeechRate(rate)

                            val utteranceId = if (index == speechItems.size - 1) "FinalPodcastLine" else "PodcastLine"
                            val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                            tts?.speak(text, queueMode, null, utteranceId)
                        }

                        statusText.value = ""
                        isLoading.value = false
                    }
                }
            }
        }
    }

    DisposableEffect(context) {
        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isRecording = true
                statusText.value = "🎤 Écoute en cours..."
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                isRecording = false
                statusText.value = "Analyse..."
            }
            override fun onError(error: Int) {
                isRecording = false
                statusText.value = ""
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    startListening()
                }
            }
            override fun onResults(results: Bundle?) {
                isRecording = false
                statusText.value = ""
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    startGeneration(matches[0])
                } else {
                    startListening()
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        speechRecognizer = recognizer

        var engineInstance: TextToSpeech? = null
        engineInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineInstance?.language = Locale.FRENCH
                ttsInitialized = true
            }
        }

        engineInstance?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isSpeaking = true
            }
            override fun onDone(utteranceId: String?) {
                if (utteranceId == "WelcomeUtterance" || utteranceId == "FinalPodcastLine") {
                    isSpeaking = false
                    mainHandler.post {
                        startListening()
                    }
                }
            }
            override fun onError(utteranceId: String?) {
                if (utteranceId == "WelcomeUtterance" || utteranceId == "FinalPodcastLine") {
                    isSpeaking = false
                    mainHandler.post {
                        startListening()
                    }
                }
            }
        })

        tts = engineInstance

        onDispose {
            recognizer.destroy()
            engineInstance?.stop()
            engineInstance?.shutdown()
        }
    }

    // Séquence unifiée : téléchargement avec jauge, initialisation et accueil vocal
    val initializeAndWelcome: () -> Unit = {
        scope.launch {
            isLoading.value = true
            try {
                withContext(Dispatchers.IO) {
                    val gemmaDownloaded = LlmManager.isModelDownloaded(context)
                    if (!gemmaDownloaded) {
                        withContext(Dispatchers.Main) { statusText.value = "Téléchargement du modèle (0%)..." }
                        val success = LlmManager.downloadModel(context) { progress ->
                            scope.launch(Dispatchers.Main) {
                                statusText.value = "Téléchargement : $progress%"
                            }
                        }
                        if (!success) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Téléchargement échoué : ${LlmManager.lastError}", false))
                            }
                        }
                    }

                    if (LlmManager.isModelDownloaded(context)) {
                        withContext(Dispatchers.Main) { statusText.value = "Initialisation de l'IA..." }
                        val inference = LlmManager.initialize(context)
                        if (inference == null) {
                            withContext(Dispatchers.Main) {
                                messages.add(ChatMessage("Castpedia AI", "⚠️ Initialisation IA échouée : ${LlmManager.lastError}", false))
                            }
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.e("MainScreen", "Erreur critique d'initialisation", e)
            } finally {
                isLoading.value = false
                statusText.value = ""

                messages[0] = ChatMessage("Castpedia", "Bonjour, je suis Castpedia. Que souhaitez-vous savoir ?", false)
                val welcomeMsg = "Bonjour, je suis Castpedia. Que souhaitez-vous savoir ?"
                tts?.speak(welcomeMsg, TextToSpeech.QUEUE_FLUSH, null, "WelcomeUtterance")
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted && ttsInitialized) {
            initializeAndWelcome()
        }
    }

    // Demande automatique de la permission micro dès le lancement si non accordée
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(ttsInitialized) {
        if (ttsInitialized && ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            initializeAndWelcome()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Assistant Vocal") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message = message)
                }
                if (isLoading.value || statusText.value.isNotEmpty() || isSpeaking || isRecording) {
                    item {
                        Text(
                            text = if (isRecording) "🎤 Écoute active..." else if (isSpeaking) "🔊 Lecture en cours..." else if (statusText.value.isNotEmpty()) statusText.value else "Traitement...",
                            color = Color(0xFFBB86FC),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { startListening() },
                    modifier = Modifier.background(if (isRecording) Color.Red else Color(0xFF1E1E1E), MaterialTheme.shapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Micro",
                        tint = if (isRecording) Color.White else Color(0xFFBB86FC)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (isRecording) "Parlez..." else "Mode mains libres actif", color = Color.Gray) },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                if (isLoading.value || isSpeaking || isRecording) {
                    Button(
                        onClick = { stopEverything() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Stop", color = Color.White)
                    }
                } else {
                    Button(
                        onClick = { startGeneration(searchQuery) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                    ) {
                        Text("Générer", color = Color.Black)
                    }
                }
            }
        }
    }
}

fun cleanKeyword(input: String): String {
    val lower = input.trim()
    val prefixes = listOf("parle moi de ", "parle-moi de ", "c'est quoi ", "qui est ", "cherche ", "info sur ")
    for (prefix in prefixes) {
        if (lower.startsWith(prefix, ignoreCase = true)) {
            return lower.substring(prefix.length).trim()
        }
    }
    return input.trim()
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

interface WikipediaApi {
    @GET("page/summary/{title}")
    suspend fun getSummary(@Path("title") title: String): WikiResponse
}

data class WikiResponse(
    val extract: String?
)

object ApiClient {
    fun <T> createService(baseUrl: String, serviceClass: Class<T>): T {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(serviceClass)
    }
}

suspend fun fetchAllApisData(keyword: String): String {
    val wikiApi = ApiClient.createService("https://fr.wikipedia.org/api/rest_v1/", WikipediaApi::class.java)

    return coroutineScope {
        val wikiDeferred = async(Dispatchers.IO) {
            try { wikiApi.getSummary(keyword) } catch (e: Exception) { null }
        }

        val wiki = wikiDeferred.await()

        val sb = StringBuilder()
        sb.append("Sujet recherché : $keyword\n\n")

        if (wiki?.extract != null) {
            sb.append("Wikipédia : ${wiki.extract}\n\n")
        } else {
            sb.append("Informations générales sur $keyword.\n\n")
        }

        sb.toString()
    }
}

