package com.castpedia.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class CastpediaState {
    GREETING,
    LISTENING,
    GENERATING,
    READY
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    llmManager: LlmManager,
    whisperManager: WhisperManager
) {
    val coroutineScope = rememberCoroutineScope()
    var appState by remember { mutableStateOf(CastpediaState.GREETING) }
    var podcastScript by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf("Bien, je suis Castpedia. Qu'est-ce que tu veux savoir aujourd'hui ?") }

    val isRecording by whisperManager.isRecording.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "studio_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    LaunchedEffect(Unit) {
        delay(600)
        appState = CastpediaState.GREETING
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia Studio") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = when (appState) {
                                CastpediaState.GREETING -> "🎙️ Assistant Castpedia"
                                CastpediaState.LISTENING -> "👂 J'écoute votre sujet..."
                                CastpediaState.GENERATING -> "✍️ Rédaction du duo Animateur / Expert..."
                                CastpediaState.READY -> "🎧 Votre Podcast est prêt"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = statusMessage,
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(180.dp)
                ) {
                    if (isRecording || appState == CastpediaState.LISTENING) {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .scale(pulseScale)
                                .background(
                                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.3f),
                                    shape = CircleShape
                                )
                        )
                    }

                    FloatingActionButton(
                        onClick = {
                            if (!isRecording) {
                                appState = CastpediaState.LISTENING
                                statusMessage = "Je vous écoute..."
                                whisperManager.startRecording()
                            } else {
                                val audioFile = whisperManager.stopRecording()
                                appState = CastpediaState.GENERATING
                                statusMessage = "Analyse de votre demande et consultation des sources..."

                                coroutineScope.launch {
                                    val result = llmManager.generatePodcastScript(
                                        topic = "Exploration des grands mystères scientifiques",
                                        wikiSummary = "Données encyclopédiques de référence.",
                                        wikidataInfo = "Identifiants Wikidata associés.",
                                        newsContext = "Flux d'actualités récentes."
                                    )

                                    result.onSuccess { script ->
                                        podcastScript = script
                                        appState = CastpediaState.READY
                                        statusMessage = "Voici votre épisode exclusif !"
                                    }.onFailure { error ->
                                        appState = CastpediaState.GREETING
                                        statusMessage = "Erreur de génération : ${error.localizedMessage}"
                                    }
                                }
                            }
                        },
                        modifier = Modifier.size(100.dp),
                        shape = CircleShape,
                        containerColor = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    ) {
                        Icon(
                            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Parler à Castpedia",
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (podcastScript.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Transcription de l'Épisode",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = podcastScript,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

