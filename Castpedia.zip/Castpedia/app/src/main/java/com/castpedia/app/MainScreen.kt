package com.castpedia.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioRecord
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

data class ChatMessage(val sender: String, val text: String, val isUser: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    var searchQuery by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>(
        ChatMessage("Castpedia", "Bonjour ! Vérification des modèles IA...", false)
    ) }
    var isLoading by remember { mutableStateOf(false) }
    var statusText by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    var isRecording by remember { mutableStateOf(false) }
    var activeAudioRecord by remember { mutableStateOf<AudioRecord?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val audioFile = File(context.cacheDir, "recorded_audio.pcm")
            activeAudioRecord = WhisperManager.recordAudio(audioFile) { recording ->
                isRecording = recording
            }
            statusText = "🎤 Enregistrement en cours... Parlez !"
        }
    }

    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    
    DisposableEffect(context) {
        var engineInstance: TextToSpeech? = null
        engineInstance = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engineInstance?.language = Locale.FRENCH
            }
        }
        tts = engineInstance
        onDispose {
            engineInstance?.stop()
            engineInstance?.shutdown()
        }
    }

    LaunchedEffect(Unit) {
        isLoading = true

        val gemmaDownloaded = withContext(Dispatchers.IO) { LlmManager.isModelDownloaded(context) }
        if (!gemmaDownloaded) {
            statusText = "Téléchargement de Gemma (0%)..."
            LlmManager.downloadModel(context) { progress ->
                statusText = "Téléchargement de Gemma : $progress%"
            }
        }
        val engine = withContext(Dispatchers.IO) { LlmManager.initialize(context) }

        val whisperDownloaded = withContext(Dispatchers.IO) { WhisperManager.isModelDownloaded(context) }
        if (!whisperDownloaded) {
            statusText = "Téléchargement de Whisper Q8 (0%)..."
            WhisperManager.downloadModel(context) { progress ->
                statusText = "Téléchargement de Whisper : $progress%"
            }
        }

        if (engine != null && WhisperManager.isModelDownloaded(context)) {
            messages.add(ChatMessage("Castpedia", "Modèles IA & Whisper prêts à l'emploi !", false))
        } else {
            messages.add(ChatMessage("Castpedia", "Prêt (certains modèles manquent ou erreur d'init).", false))
        }

        isLoading = false
        statusText = ""
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Castpedia - Local AI & APIs") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF121212),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFF121212)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages) { message ->
                    MessageBubble(message = message)
                }
                if (isLoading || statusText.isNotEmpty()) {
                    item {
                        Text(
                            text = if (statusText.isNotEmpty()) statusText else "Traitement en cours...",
                            color = Color.Gray,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (!isRecording) {
                            val permissionCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                                val audioFile = File(context.cacheDir, "recorded_audio.pcm")
                                activeAudioRecord = WhisperManager.recordAudio(audioFile) { recording ->
                                    isRecording = recording
                                }
                                statusText = "🎤 Enregistrement en cours... Parlez !"
                            } else {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        } else {
                            activeAudioRecord?.stop()
                            activeAudioRecord?.release()
                            activeAudioRecord = null
                            isRecording = false
                            statusText = "Transcription de la voix..."

                            coroutineScope.launch {
                                val audioFile = File(context.cacheDir, "recorded_audio.pcm")
                                if (audioFile.exists()) {
                                    val transcribedText = WhisperManager.transcribeAudio(context, audioFile)
                                    if (transcribedText.isNotBlank()) {
                                        searchQuery = transcribedText
                                    }
                                }
                                statusText = ""
                            }
                        }
                    },
                    modifier = Modifier.background(if (isRecording) Color.Red else Color(0xFF1E1E1E), MaterialTheme.shapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Micro",
                        tint = if (isRecording) Color.White else Color(0xFFBB86FC)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (isRecording) "En écoute..." else "Ex: Japon, Louis XIV...", color = Color.Gray) },
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1E1E1E), MaterialTheme.shapes.small),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFFBB86FC),
                        unfocusedBorderColor = Color.Gray
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        if (searchQuery.isNotBlank() && !isLoading) {
                            val userPrompt = searchQuery
                            val cleanedKeyword = cleanKeyword(userPrompt)
                            
                            messages.add(ChatMessage("Moi", userPrompt, true))
                            searchQuery = ""
                            isLoading = true

                            coroutineScope.launch {
                                statusText = "Recherche des données..."
                                val rawData = fetchAllApisData(cleanedKeyword)
                                
                                statusText = ""
                                val aiMessageIndex = messages.size
                                messages.add(ChatMessage("Castpedia AI", "✍️ Génération du premier bloc...", false))
                                
                                var lastReadLength = 0

                                LlmManager.generatePodcastScript(rawData) { currentScript ->
                                    messages[aiMessageIndex] = ChatMessage("Castpedia AI", currentScript, false)

                                    if (currentScript.length > lastReadLength) {
                                        val newChunk = currentScript.substring(lastReadLength)
                                            .replace("#", "")
                                            .replace("*", "")
                                            .trim()

                                        lastReadLength = currentScript.length

                                        if (newChunk.isNotBlank()) {
                                            tts?.speak(newChunk, TextToSpeech.QUEUE_ADD, null, null)
                                        }
                                    }
                                }

                                isLoading = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBB86FC))
                ) {
                    Text("Générer", color = Color.Black)
                }
            }
        }
    }
}

fun cleanKeyword(input: String): String {
    val lower = input.trim()
    val prefixes = listOf("parle moi de ", "parle-moi de ", "c'est quoi ", "qui est ", "cherche ", "info sur ")
    for (prefix in prefixes) {
        if (lower.startsWith(prefix, ignoreCase = true)) {
            return lower.substring(prefix.length).trim()
        }
    }
    return input.trim()
}

@Composable
fun MessageBubble(message: ChatMessage) {
    val backgroundColor = if (message.isUser) Color(0xFF333333) else Color(0xFF1E1E1E)
    val textColor = if (message.isUser) Color.White else Color(0xFFE0E0E0)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        contentAlignment = if (message.isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = backgroundColor,
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = message.sender,
                    color = Color(0xFFBB86FC),
                    style = MaterialTheme.typography.labelSmall
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = message.text,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

suspend fun fetchAllApisData(keyword: String): String {
    val wikiApi = ApiClient.createService("https://fr.wikipedia.org/api/rest_v1/", WikipediaApi::class.java)

    return coroutineScope {
        val wikiDeferred = async(Dispatchers.IO) {
            try { wikiApi.getSummary(keyword) } catch (e: Exception) { null }
        }

        val wiki = wikiDeferred.await()

        val sb = StringBuilder()
        sb.append("Sujet recherché : $keyword\n\n")

        if (wiki != null) {
            try {
                sb.append("Wikipédia : ${wiki.extract}\n\n")
            } catch (e: Exception) {
                sb.append("Informations disponibles sur $keyword.\n\n")
            }
        } else {
            sb.append("Sujet : $keyword\n\n")
        }

        sb.toString()
    }
}

