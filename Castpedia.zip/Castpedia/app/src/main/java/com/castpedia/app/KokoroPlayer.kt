package com.castpedia.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession

class KokoroPlayer(private val context: Context) {

    private var ortEnvironment: OrtEnvironment? = null
    private var ortSession: OrtSession? = null
    private var audioTrack: AudioTrack? = null
    private var isInitialized = false

    /**
     * Initialise le moteur ONNX Runtime et configure l'AudioTrack à 24kHz.
     */
    fun initialize(): Boolean {
        try {
            if (isInitialized) return true

            val modelFile = KokoroManager.getModelFile(context)
            if (!modelFile.exists() || modelFile.length() == 0L) {
                return false
            }

            // Initialisation de l'environnement ONNX
            ortEnvironment = OrtEnvironment.getEnvironment()
            val sessionOptions = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(4)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }
            
            // Chargement du modèle ONNX en mémoire
            ortSession = ortEnvironment?.createSession(modelFile.absolutePath, sessionOptions)
            
            // Configuration de la sortie AudioTrack (24 000 Hz, Float PCM, Mono)
            val sampleRate = 24000
            val bufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_FLOAT
            )

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize.coerceAtLeast(bufferSize * 2))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
            isInitialized = true
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /**
     * Indique si l'environnement et la session ONNX sont prêts.
     */
    fun isReady(): Boolean = isInitialized && ortSession != null

    /**
     * Libération propre des ressources lors de la fermeture de l'application.
     */
    fun release() {
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
            
            ortSession?.close()
            ortSession = null
            
            ortEnvironment?.close()
            ortEnvironment = null
            
            isInitialized = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

