package com.castpedia.app.ui

import retrofit2.http.GET
import retrofit2.http.Query

data class WikidataSearchResponse(
    val search: List<WikidataEntity>?
)

data class WikidataEntity(
    val id: String,
    val label: String,
    val description: String?
)

interface WikidataApi {
    @GET("api.php?action=wbsearchentities&format=json&language=fr")
    suspend fun searchEntity(
        @Query("search") query: String
    ): WikidataSearchResponse
}
