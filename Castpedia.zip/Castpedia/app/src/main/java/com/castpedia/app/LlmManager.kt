package com.castpedia.app.ui

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()
            val request = Request.Builder().url(MODEL_URL).header("User-Agent", "CastpediaApp/1.0").build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }
                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(1024)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Génère le podcast en streaming : envoie chaque chapitre dès qu'il est prêt !
     */
    fun generatePodcastStream(rawData: String): Flow<String> = flow {
        if (llmInference == null && appContext != null) {
            initialize(appContext!!)
        }

        val inference = llmInference 
        if (inference == null) {
            emit("Erreur : Le modèle n'est pas initialisé.")
            return@flow
        }

        // 1. Étape du plan
        emit("📢 Création du plan de l'épisode (8 chapitres)...\n")
        val planPrompt = "Agis en tant que producteur de podcast professionnel. " +
                "Crée un plan structuré exactement en 8 grands chapitres pour un podcast long et immersif sur le sujet : '$rawData'. " +
                "Donne uniquement la liste des titres des chapitres sous forme de liste numérotée."
        
        val planResponse = inference.generateResponse(planPrompt)
        if (planResponse.isNullOrBlank()) {
            emit("Erreur : Impossible de générer le plan.")
            return@flow
        }

        val chapters = planResponse.lines()
            .filter { it.trim().matches(Regex("^\\d+.*")) }
            .ifEmpty { 
                listOf(
                    "1. Introduction et mise en contexte", 
                    "2. Les origines et l'histoire", 
                    "3. Les fondements culturels", 
                    "4. Les moments charnières",
                    "5. Les figures clés",
                    "6. Les paradoxes modernes", 
                    "7. Anecdotes fascinantes", 
                    "8. Conclusion"
                ) 
            }

        emit("🎧 **Sommaire validé ! Début de la diffusion immédiate du Chapitre 1...**\n\n---\n\n")

        // 2. Boucle de génération et d'envoi chapitre par chapitre en temps réel
        for ((index, chapterTitle) in chapters.withIndex()) {
            val currentStep = index + 1
            
            val chapterPrompt = "Tu rédiges un script audio pour un podcast long, vivant et captivant. " +
                    "Sujet global : '$rawData'. " +
                    "Rédige de façon très développée et riche le contenu complet de ce chapitre spécifique : '$chapterTitle'."

            val chapterContent = inference.generateResponse(chapterPrompt)

            // Dès qu'un chapitre est fini, on l'envoie (emit) instantanément à l'écran !
            val chunk = "## Chapitre $currentStep : $chapterTitle\n\n${chapterContent ?: "Contenu en cours..."}\n\n---\n\n"
            emit(chunk)
        }

        emit("✨ **Épisode complet généré avec succès !**")
    }.flowOn(Dispatchers.IO)
}

