package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    private val inferenceMutex = Mutex()

    var lastError: String = "Aucune erreur enregistrée"
        private set

    private val hostPairs = listOf(
        Pair("Thomas", "Julie"),
        Pair("Marc", "Sophie"),
        Pair("Alexandre", "Léa"),
        Pair("Julien", "Camille"),
        Pair("Lucas", "Élodie"),
        Pair("Hugo", "Sarah"),
        Pair("Maxime", "Chloé")
    )

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Échec du renommage du fichier"
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur réseau"}"
            Log.e(TAG, "Erreur téléchargement", e)
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) {
            lastError = "Fichier modèle introuvable"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            if (llmInference == null) {
                lastError = "LlmInference a retourné null"
                file.delete()
            }
            return llmInference
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur d'inférence"}"
            Log.e(TAG, "Erreur initialisation LlmInference", e)
            file.delete()
            return null
        }
    }

    suspend fun generatePodcastStream(
        rawData: String,
        userLanguage: String,
        onBlockGenerated: (host1: String, host2: String, blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference
            if (inference == null) {
                lastError = "Modèle non initialisé"
                return@withContext
            }

            try {
                val randomPair = hostPairs.random()
                val host1 = randomPair.first
                val host2 = randomPair.second

                // TIMELINE CHRONOLOGIQUE STRICTE BASÉE SUR LA FICHE WIKIPÉDIA
                val group1 = listOf(
                    "Introduction factuelle : présentation immédiate du sujet selon Wikipédia.",
                    "Chronologie - Étape 1 : Les origines, la jeunesse et le contexte de départ.",
                    "Chronologie - Étape 2 : Les débuts, les premiers actes ou projets marquants.",
                    "Chronologie - Étape 3 : L'ascension, les faits majeurs et les réalisations clés.",
                    "Chronologie - Étape 4 : Les tournants historiques ou professionnels décisifs.",
                    "Chronologie - Étape 5 : L'apogée des actions et l'impact direct mesuré.",
                    "Chronologie - Étape 6 : Les oppositions, difficultés ou contextes complexes rencontrés.",
                    "Chronologie - Étape 7 : Les réformes, créations ou innovations apportées.",
                    "Chronologie - Étape 8 : La période de transition ou les derniers grands projets.",
                    "Chronologie - Étape 9 : Bilan de la première partie de la chronologie."
                )

                val group2 = listOf(
                    "Chronologie - Étape 10 : Poursuite des faits, fin de parcours ou situation finale.",
                    "Chronologie - Étape 11 : L'impact global et la postérité objective.",
                    "Chronologie - Étape 12 : Les critiques historiques et l'analyse factuelle.",
                    "Chronologie - Étape 13 : La trace institutionnelle ou culturelle laissée.",
                    "Chronologie - Étape 14 : Les distinctions, hommages ou commémorations officiels.",
                    "Chronologie - Étape 15 : Les archives et documents de référence associés.",
                    "Chronologie - Étape 16 : Synthèse des aspects techniques ou politiques.",
                    "Chronologie - Étape 17 : Regard croisé purement factuel entre les animateurs.",
                    "Chronologie - Étape 18 : Rappel des dates et faits clés indiscutables.",
                    "Conclusion factuelle rapide de l'émission par $host1 et $host2."
                )

                val allSections = group1 + group2

                for ((index, section) in allSections.withIndex()) {
                    val partNum = if (index < 10) "Partie 1 (Bloc ${index + 1}/10)" else "Partie 2 (Bloc ${index - 9}/10)"
                    onProgressUpdate("Génération - $partNum...")

                    val langInstruction = if (userLanguage == "fr") {
                        "Rédige STRICTEMENT en FRANÇAIS."
                    } else {
                        "Write STRICTLY in English (or user language: $userLanguage)."
                    }

                    val prompt = """
                        $langInstruction
                        Tu animes un podcast documentaire factuel et chronologique avec deux personnes : $host1 et $host2.
                        INFORMATIONS OFFICIELLES WIKIPÉDIA (SOURCE UNIQUE DE VÉRITÉ) :
                        $rawData
                        
                        Étape chronologique actuelle ($partNum) : $section
                        
                        RÈGLES D'OR ABSOLUES :
                        1. INTERDICTION TOTALE d'inventer, d'halluciner ou de raconter des fictions (pas de faux métiers ou de fausses identités). Si le sujet est un personnage historique comme Napoléon ou Louis XIV, respecte scrupuleusement son histoire réelle.
                        2. PAS DE BLABLA ÉMOTIONNEL. Zéro compliment subjectif ("c'est une personne incroyable..."). Reste strictement factuel et informatif en suivant la chronologie Wikipédia.
                        3. ${if (index == 0) "$host1 énonce immédiatement le sujet factuel en une phrase, et $host2 enchaîne." else "Poursuis directement la chronologie sans dire bonjour."}
                        4. Utilise STRICTEMENT les prénoms $host1 et $host2 au format exact "Nom: Réplique".
                        5. Pas d'horodatage, pas d'astérisques, uniquement du texte parlé brut.
                        6. Format obligatoire :
                           $host1: [Réplique]
                           $host2: [Réplique]
                    """.trimIndent()

                    val chunk = inference.generateResponse(prompt)

                    if (!chunk.isNullOrBlank()) {
                        onProgressUpdate(chunk)
                        onBlockGenerated(host1, host2, chunk)
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Erreur streaming génération", e)
                lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur"}"
            }
        }
    }
}

