
package com.castpedia.app.ui

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object LlmManager {
    private var llmInference: LlmInference? = null

    private const val MODEL_URL = "https://huggingface.co/google/gemma-1.1-2b-it-gpu-int4/resolve/main/gemma-1.1-2b-it-gpu-int4.bin"
    private const val MODEL_FILENAME = "gemma-3-1b-it.bin"

    fun isModelDownloaded(context: Context): Boolean {
        val file = File(context.filesDir, MODEL_FILENAME)
        return file.exists() && file.length() > 0
    }

    // Téléchargement robuste avec gestion explicite des redirections (HuggingFace CDN)
    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, MODEL_FILENAME)
        if (targetFile.exists() && targetFile.length() > 0) return@withContext true

        try {
            var downloadUrl = MODEL_URL
            var connection: HttpURLConnection

            // Boucle pour suivre les redirections du serveur (HuggingFace -> CDN)
            while (true) {
                val url = URL(downloadUrl)
                connection = url.openConnection() as HttpURLConnection
                connection.instanceFollowRedirects = false
                val responseCode = connection.responseCode

                if (responseCode == HttpURLConnection.HTTP_MOVED_TEMP ||
                    responseCode == HttpURLConnection.HTTP_MOVED_PERM ||
                    responseCode == HttpURLConnection.HTTP_SEE_OTHER ||
                    responseCode == 307 || responseCode == 308) {
                    val redirectUrl = connection.getHeaderField("Location")
                    if (redirectUrl != null) {
                        downloadUrl = redirectUrl
                        connection.disconnect()
                        continue
                    }
                }
                break
            }

            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                return@withContext false
            }

            val fileLength = connection.contentLength
            val input = connection.inputStream
            val output = FileOutputStream(targetFile)

            val data = ByteArray(8192)
            var total: Long = 0
            var count: Int

            while (input.read(data).also { count = it } != -1) {
                total += count.toLong()
                if (fileLength > 0) {
                    val progress = (total * 100 / fileLength).toInt()
                    onProgress(progress)
                }
                output.write(data, 0, count)
            }

            output.flush()
            output.close()
            input.close()
            return@withContext true
        } catch (e: Exception) {
            e.printStackTrace()
            if (targetFile.exists()) targetFile.delete()
            return@withContext false
        }
    }

    fun initialize(context: Context): Boolean {
        if (llmInference != null) return true

        val modelFile = File(context.filesDir, MODEL_FILENAME)
        if (!modelFile.exists()) return false

        return try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun generatePodcastScript(rawApiData: String): String = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            return@withContext "Modèle LLM non initialisé. Données brutes :\n\n$rawApiData"
        }

        val prompt = """
            Tu es un animateur de podcast passionné et dynamique. 
            À partir des informations suivantes, rédige un court script de podcast captivant, fluide et vivant en français (style conversationnel, prêt à être lu à voix haute) :
            
            $rawApiData
        """.trimIndent()

        try {
            return@withContext llmInference?.generateResponse(prompt) ?: "Erreur de génération du script."
        } catch (e: Exception) {
            return@withContext "Erreur lors de la génération IA : ${e.localizedMessage}"
        }
    }
}
