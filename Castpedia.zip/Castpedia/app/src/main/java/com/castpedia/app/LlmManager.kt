package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"
    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    private val inferenceMutex = Mutex()

    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File = File(context.filesDir, MODEL_NAME)

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")
        try {
            if (tempFile.exists()) tempFile.delete()
            val request = Request.Builder().url(MODEL_URL).header("User-Agent", "CastpediaApp/1.0").build()
            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext false
                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                onProgress(((total * 100) / expected).toInt())
                            }
                        }
                        output.flush()
                    }
                }
                if (expected > 0 && total != expected) {
                    tempFile.delete()
                    return@withContext false
                }
            }
            if (modelFile.exists()) modelFile.delete()
            return@withContext tempFile.renameTo(modelFile)
        } catch (_: Throwable) {
            if (tempFile.exists()) tempFile.delete()
            return@withContext false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()
            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (_: Throwable) {
            file.delete()
            return null
        }
    }

    suspend fun generatePodcastStream(
        topic: String,
        rawData: String,
        userLanguage: String,
        onBlockGenerated: (blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            if (llmInference == null && appContext != null) initialize(appContext!!)
            val inference = llmInference ?: return@withContext

            try {
                // 1. INTRODUCTION
                onProgressUpdate("Génération - Introduction...")
                val introPrompt = """
                TU ES UN GÉNÉRATEUR DE PODCAST DOCUMENTAIRE.
                Sujet : $topic
                
                RÈGLES ABSOLUES :
                - Une seule introduction au début du podcast.
                - Ne jamais répéter "bonjour" ou "bienvenue".
                - Ne jamais inventer d'émission, de contexte ou d'informations.
                - Ne jamais ajouter d'opinion.
                - Ne jamais dire "merci pour l'invitation".
                - Ne jamais parler d'informations absentes de Wikipédia.
                - Ne jamais écrire "voici un podcast" ou "voici un script".
                - Ne jamais expliquer le fonctionnement de Wikipédia.
                - Si une information n'est pas présente dans Wikipédia, ne pas la mentionner.
                
                DONNÉES WIKIPÉDIA :
                $rawData
                
                STRUCTURE :
                Animateur : "Bonjour et bienvenue dans ce podcast consacré à $topic."
                Animateur : "Pour commencer, qui est $topic ?"
                Expert : [Réponse uniquement basée sur le résumé introductif Wikipédia]
                
                FORMAT DE SORTIE :
                Animateur : ...
                Expert : ...
                Aucun autre texte. Aucun titre. Aucune numérotation.
                """.trimIndent()

                val introResponse = inference.generateResponse(introPrompt)
                currentCoroutineContext().ensureActive()
                if (!introResponse.isNullOrBlank()) {
                    onBlockGenerated(introResponse)
                }

                // 2. DÉVELOPPEMENT (Sections H2 / H3)
                val sections = extractSections(rawData)
                for ((secIndex, section) in sections.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    onProgressUpdate("Génération - Section ${secIndex + 1}/${sections.size} (${section.title})...")

                    val secPrompt = """
                    TU ES UN GÉNÉRATEUR DE PODCAST DOCUMENTAIRE.
                    Sujet : $topic
                    Section Wikipédia : "${section.title}"
                    
                    RÈGLES ABSOLUES :
                    - INTERDICTION ABSOLUE de dire "bonjour" ou "bienvenue".
                    - Ne jamais inventer d'informations ou d'opinions.
                    - Si une information n'est pas présente dans Wikipédia, ne pas la mentionner.
                    
                    CONTENU DE LA SECTION :
                    ${section.content}
                    
                    STRUCTURE :
                    Animateur : "Que sait-on de ${section.title} pour $topic ?" (ou question adaptée au titre de la section)
                    Expert : [Réponse uniquement à partir du contenu de cette section]
                    
                    FORMAT DE SORTIE :
                    Animateur : ...
                    Expert : ...
                    Aucun autre texte. Aucun titre. Aucune numérotation.
                    """.trimIndent()

                    val secResponse = inference.generateResponse(secPrompt)
                    currentCoroutineContext().ensureActive()
                    if (!secResponse.isNullOrBlank()) {
                        onBlockGenerated(secResponse)
                    }
                }

                // 3. CONCLUSION
                onProgressUpdate("Génération - Conclusion...")
                val conclusionPrompt = """
                TU ES UN GÉNÉRATEUR DE PODCAST DOCUMENTAIRE.
                Sujet : $topic
                
                RÈGLES ABSOLUES :
                - Ne jamais inventer d'informations.
                - Résumé uniquement basé sur les informations déjà présentées.
                
                STRUCTURE :
                Animateur : "Pour conclure, que peut-on retenir de $topic ?"
                Expert : [Résumé uniquement basé sur les informations déjà présentées]
                
                FORMAT DE SORTIE :
                Animateur : ...
                Expert : ...
                Aucun autre texte. Aucun titre. Aucune numérotation.
                """.trimIndent()

                val conclusionResponse = inference.generateResponse(conclusionPrompt)
                currentCoroutineContext().ensureActive()
                if (!conclusionResponse.isNullOrBlank()) {
                    onBlockGenerated(conclusionResponse)
                }

            } catch (e: Throwable) {
                Log.e(TAG, "Erreur génération podcast", e)
            }
        }
    }

    private data class WikiSection(val title: String, val content: String)

    private fun extractSections(raw: String): List<WikiSection> {
        val list = mutableListOf<WikiSection>()
        val lines = raw.split("\n")
        var currentTitle = "Développement"
        var currentContent = StringBuilder()

        for (line in lines) {
            if (line.startsWith("==") || line.startsWith("=== ")) {
                if (currentContent.isNotEmpty()) {
                    list.add(WikiSection(currentTitle, currentContent.toString()))
                    currentContent = StringBuilder()
                }
                currentTitle = line.replace("=", "").trim()
            } else {
                currentContent.append(line).append("\n")
            }
        }
        if (currentContent.isNotEmpty()) {
            list.add(WikiSection(currentTitle, currentContent.toString()))
        }
        if (list.isEmpty()) {
            list.add(WikiSection("Généralités", raw))
        }
        return list.take(8)
    }
}

