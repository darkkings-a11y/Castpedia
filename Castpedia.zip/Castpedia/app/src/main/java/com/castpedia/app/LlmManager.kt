
package com.example.castpedia.utils // Adapte le package selon ton projet si nécessaire

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int8-web.task"
    
    // Ton URL directe GitHub release v1.1
    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int8-web.task"

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024 
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)

        try {
            val url = URL(MODEL_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.instanceFollowRedirects = true
            connection.connect()

            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                lastError = "Erreur serveur : Code HTTP $responseCode"
                connection.disconnect()
                return@withContext false
            }

            val fileLength = connection.contentLength
            
            if (modelFile.exists() && fileLength > 0 && modelFile.length() == fileLength.toLong()) {
                connection.disconnect()
                onProgress(100)
                return@withContext true
            }

            val inputStream = connection.inputStream
            val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

            tempFile.outputStream().use { outputStream ->
                val data = ByteArray(8192)
                var total: Long = 0
                var count: Int
                while (inputStream.read(data).also { count = it } != -1) {
                    total += count.toLong()
                    if (fileLength > 0) {
                        val progress = ((total * 100) / fileLength).toInt()
                        onProgress(progress)
                    }
                    outputStream.write(data, 0, count)
                }
                outputStream.flush()
            }

            inputStream.close()
            connection.disconnect()

            if (tempFile.exists() && fileLength > 0 && tempFile.length() == fileLength.toLong()) {
                if (modelFile.exists()) modelFile.delete()
                tempFile.renameTo(modelFile)
                Log.d(TAG, "Modèle téléchargé et vérifié avec succès : ${modelFile.absolutePath}")
                true
            } else {
                lastError = "Fichier corrompu ou incomplet (taille reçue ${tempFile.length()} / attendue $fileLength)"
                if (tempFile.exists()) tempFile.delete()
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du téléchargement du modèle", e)
            lastError = "Erreur réseau : ${e.localizedMessage ?: e.javaClass.simpleName}"
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) {
            lastError = "Fichier modèle introuvable dans ${file.absolutePath}"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(1024)
                .setTemperature(0.7f)
                .setPreferredBackend(LlmInference.Backend.CPU) // Forçage CPU pour éviter le bug GPU Qualcomm
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            Log.d(TAG, "MediaPipe LlmInference initialisé avec succès sur CPU (Gemma 3 1B INT8) !")
            return llmInference
        } catch (e: Exception) {
            Log.e(TAG, "Échec de l'initialisation de MediaPipe", e)
            lastError = "Erreur MediaPipe : ${e.localizedMessage ?: e.javaClass.simpleName}"
            return null
        }
    }

    suspend fun generatePodcastScript(rawData: String): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: run {
                return@withContext "Erreur d'initialisation : $lastError"
            }
            
            val prompt = "À partir des informations suivantes, rédige un script de podcast captivant et fluide :\n\n$rawData"
            val response = inference.generateResponse(prompt)
            response ?: "Aucune réponse générée par le modèle."
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la génération du podcast", e)
            "Erreur de génération : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}
