package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    private val inferenceMutex = Mutex()

    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Échec du renommage du fichier"
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur réseau"}"
            Log.e(TAG, "Erreur téléchargement", e)
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        val fileLength = file.length()
        if (!file.exists() || fileLength == 0L) {
            lastError = "Fichier modèle introuvable"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            if (llmInference == null) {
                lastError = "LlmInference a retourné null"
                file.delete()
            }
            return llmInference
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur d'inférence"}"
            Log.e(TAG, "Erreur initialisation LlmInference", e)
            file.delete()
            return null
        }
    }

    // Découpe l'article Wikipédia en petits morceaux (le modèle a une mémoire courte)
    private fun splitIntoChunks(rawData: String, maxChars: Int = 450, maxChunks: Int = 20): List<String> {
        val marker = "CONTENU WIKIPÉDIA"
        val body = if (rawData.contains(marker)) {
            rawData.substringAfter(marker).substringAfter("\n")
        } else {
            rawData
        }
        val paragraphs = body.lines()
            .map { it.trim() }
            .filter { it.isNotBlank() && !it.startsWith("==") }

        val chunks = mutableListOf<String>()
        val current = StringBuilder()

        fun flush() {
            val text = current.toString().trim()
            if (text.isNotEmpty()) chunks.add(text)
            current.clear()
        }

        for (p in paragraphs) {
            val pieces = if (p.length > maxChars) p.split(Regex("(?<=[.!?])\\s+")) else listOf(p)
            for (piece in pieces) {
                if (current.isNotEmpty() && current.length + piece.length > maxChars) flush()
                current.append(piece).append(' ')
            }
        }
        flush()
        return chunks.take(maxChunks)
    }

    // Nettoie la sortie du modèle : une phrase par ligne, sans deux-points ni mise en forme
    private fun cleanChunk(text: String): String {
        return text
            .replace("*", "")
            .replace("#", "")
            .replace(":", ",")
            .lines()
            .map { it.trim() }
            .filter { line ->
                val l = line.lowercase()
                line.isNotBlank() &&
                    !l.startsWith("bien sûr") &&
                    !l.startsWith("voici") &&
                    !l.startsWith("sure") &&
                    !l.startsWith("here")
            }
            .flatMap { it.split(Regex("(?<=[.!?…])\\s+")) }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .joinToString("\n")
    }

        private fun buildPrompt(
        source: String,
        topic: String,
        isFirst: Boolean,
        isLast: Boolean,
        lastSentence: String,
        userLanguage: String
    ): String {
        val langInstruction = if (userLanguage == "fr") {
            "Rédige STRICTEMENT en FRANÇAIS."
        } else {
            "Write STRICTLY in the user's language ($userLanguage)."
        }

        val lines = mutableListOf<String>()
        lines.add(langInstruction)
        lines.add("TU ES LE MOTEUR DE NARRATION DE CASTPEDIA.")
        lines.add("Objectif : Produire un récit documentaire continu à UNE SEULE VOIX à partir de l'extrait Wikipédia/Wikidata fourni.")
        lines.add("Le podcast n'est PAS une conversation, PAS une émission de radio, PAS une interview.")
        lines.add("")
        lines.add("EXTRAIT WIKIPÉDIA À RACONTER :")
        lines.add(source)
        lines.add("")
        lines.add("RÈGLES STRICTES :")
        lines.add("- Raconte uniquement ce que dit cet extrait. N'invente rien, n'ajoute aucune connaissance générale, aucun fait, date, citation ou expert absent du texte.")
        lines.add("- Écris dans un style oral, vivant et naturel, par blocs de 2 à 4 phrases courtes.")
        lines.add("- Pas de titres, pas de listes, pas de deux-points, pas d'astérisques, pas de mise en scène.")
        
        if (isFirst) {
            lines.add("- INTRODUCTION : Commence par une seule phrase d'accueil (ex: \"Bonjour et bienvenue dans ce podcast consacré à $topic.\"), puis présente le sujet à partir de l'introduction Wikipédia.")
        } else {
            lines.add("- Ne dis pas bonjour, ne refais pas d'introduction. Enchaîne naturellement en utilisant des transitions fluides (ex: \"Revenons maintenant à...\", \"Intéressons-nous ensuite à...\", \"Poursuivons avec...\").")
            if (lastSentence.isNotBlank()) {
                lines.add("- Dernière phrase déjà dite : \"$lastSentence\"")
            }
        }

        if (isLast) {
            lines.add("- CONCLUSION : Termine par un résumé des principaux éléments évoqués, sans ajouter de nouvelles informations.")
        }

        lines.add("")
        lines.add("INTERDICTIONS ABSOLUES :")
        lines.add("- Ne jamais employer : \"Merci de votre invitation\", \"Je suis ravi d'être ici\", \"Bonjour à tous\" répété, \"Dans cette émission\", \"Comme vous le savez\", \"Selon mon avis\", \"Je pense que\", \"Voici un script\", \"Voici un podcast\".")
        lines.add("- N'invente aucun dialogue, animateur, expert, anecdote ou élément externe.")
        lines.add("")
        lines.add("FORMAT DE SORTIE : Uniquement le texte final du podcast destiné à la synthèse vocale, sans aucun méta-commentaire, titre ou numérotation.")

        return lines.joinToString("\n")
    }


    suspend fun generatePodcastStream(
        rawData: String,
        userLanguage: String,
        onBlockGenerated: (host1: String, host2: String, blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference
            if (inference == null) {
                lastError = "Modèle non initialisé"
                return@withContext
            }

            try {
                val chunks = splitIntoChunks(rawData)
                if (chunks.isEmpty()) {
                    lastError = "Aucun contenu Wikipédia à raconter"
                    return@withContext
                }

                val topic = rawData.lineSequence().firstOrNull()
                    ?.substringAfter(":", "")
                    ?.trim()
                    .orEmpty()

                val total = chunks.size
                var lastSentence = ""

                for ((index, source) in chunks.withIndex()) {
                    currentCoroutineContext().ensureActive()
                    onProgressUpdate("Génération du podcast - bloc ${index + 1}/$total...")

                    val prompt = buildPrompt(
                        source = source,
                        topic = topic,
                        isFirst = index == 0,
                        isLast = index == total - 1,
                        lastSentence = lastSentence,
                        userLanguage = userLanguage
                    )

                    val raw = inference.generateResponse(prompt)

                    currentCoroutineContext().ensureActive()

                    val cleaned = cleanChunk(raw ?: "")
                    if (cleaned.isNotBlank()) {
                        lastSentence = cleaned.lines().last()
                        // Un seul narrateur : on envoie des noms vides, MainScreen lit tout avec la voix 0
                        onBlockGenerated("", "", cleaned)
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Erreur streaming génération", e)
                lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur"}"
            }
        }
    }
}
