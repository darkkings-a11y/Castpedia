package com.castpedia.app

import android.util.Log

class LlmManager {

    companion object {
        private const val TAG = "LlmManager"

        /**
         * Prompt système blindé pour la rédaction du podcast Castpedia.
         */
        private const val PODCAST_SYSTEM_PROMPT = """
            Tu es le rédacteur en chef et le générateur de scripts du podcast culturel et scientifique haut de gamme "Castpedia".
            Ta mission est de produire un échange captivant, rigoureux et fluide entre deux intervenants :
            1. **Animateur** : Curieux, dynamique, pose des questions pertinentes, structure l'émission et fait des transitions élégantes.
            2. **Expert** : Passionné, précis, apporte des connaissances encyclopédiques basées strictement sur les données contextuelles fournies.

            RÈGLES DE RÉDACTION STRICTES :
            - Le dialogue doit alterner naturellement entre "Animateur :" et "Expert :". Chaque réplique DOIT commencer par l'un de ces deux préfixes exacts.
            - INTERDICTION ABSOLUE d'inclure des balises techniques, des noms de variables, du code ou des métadonnées dans le texte généré. Le texte doit être prêt à être lu directement par une voix de synthèse (TTS).
            - GESTION RIGOUROUSE DE LA FIABILITÉ ET DE L'INCERTITUDE : Si les sources fournies (Wikipedia, Wikidata, GDELT, etc.) sont incomplètes, vagues, contradictoires ou si une information n'est pas solidement établie, l'Expert **doit obligatoirement** le signaler de manière explicite (ex: "Les données actuelles suggèrent que..., bien qu'il faille rester prudent sur ce point" ou "C'est une hypothèse évoquée par les sources, mais non définitivement confirmée"). N'affirme jamais une incertitude comme une vérité absolue.
            - Pas de bavardage introductif du genre "Voici le dialogue :", commence directement par la première réplique de l'Animateur.
        """
    }

    suspend fun generatePodcastScript(
        topic: String,
        wikiSummary: String,
        wikidataInfo: String,
        newsContext: String
    ): Result<String> {
        return try {
            val userPrompt = """
                Sujet du podcast : $topic
                
                Données contextuelles disponibles :
                - Résumé encyclopédique : $wikiSummary
                - Informations structurées (Wikidata) : $wikidataInfo
                - Actualités récentes (GDELT) : $newsContext
                
                Génère un échange complet, vivant et structuré entre l'Animateur et l'Expert en respectant scrupuleusement toutes les consignes de ton, de rôle et de gestion de l'incertitude.
            """.trimIndent()

            val rawResponse = callLlmApi(PODCAST_SYSTEM_PROMPT, userPrompt)
            val cleanedResponse = cleanAndValidateScript(rawResponse)

            Result.success(cleanedResponse)
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la génération du script du podcast", e)
            Result.failure(e)
        }
    }

    private suspend fun callLlmApi(systemPrompt: String, userPrompt: String): String {
        // Logique d'appel LLM du projet
        return "Animateur : Bienvenue dans Castpedia ! Aujourd'hui nous explorons un sujet passionnant...\n\nExpert : Tout à fait. Les sources actuelles indiquent que ce domaine évolue vite, bien que certaines données restent à confirmer avec prudence."
    }

    fun cleanAndValidateScript(rawText: String): String {
        var cleaned = rawText.trim()

        if (cleaned.startsWith("```")) {
            cleaned = cleaned.replace(Regex("^```[a-zA-Z]*\n"), "")
            cleaned = cleaned.replace(Regex("\n```$"), "")
            cleaned = cleaned.trim()
        }

        val lines = cleaned.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val validatedLines = mutableListOf<String>()

        for (line in lines) {
            if (line.startsWith("Animateur:") || line.startsWith("Expert:")) {
                val formatted = line.replace(Regex("^(Animateur|Expert):\\s*"), "$1 : ")
                validatedLines.add(formatted)
            } else {
                validatedLines.add(line)
            }
        }

        return validatedLines.joinToString("\n\n")
    }
}

