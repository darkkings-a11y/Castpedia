package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Génération progressive en 20 blocs pour atteindre le format cible de 30 minutes.
     */
    suspend fun generatePodcastScript(
        rawData: String,
        onProgressUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: return@withContext "Erreur d'initialisation : $lastError"

            val host1 = "Thomas"
            val host2 = "Julie"

            // 20 sections thématiques précises pour couvrir 30 minutes de contenu
            val sections = listOf(
                "Introduction générale : $host1 accueille $host2, présentent le sujet et la grande aventure du jour.",
                "Origines lointaines, géographie et premières traces dans l'histoire.",
                "Les mythes fondeurs, mythes et légendes populaires.",
                "L'Antiquité et la structuration des premières communautés.",
                "Les grandes figures historiques de la première époque.",
                "L'organisation sociale, la culture et la vie quotidienne d'autrefois.",
                "Les premiers grands événements majeurs et tournants historiques.",
                "Les guerres, batailles ou révolutions qui ont tout changé.",
                "L'évolution de la politique, des dirigeants et des lois d'autrefois.",
                "L'âge d'or culturel, les arts, la littérature et la pensée.",
                "Les relations avec les pays voisins et les influences extérieures.",
                "Les grandes découvertes, innovations et évolutions économiques.",
                "La transition vers l'ère industrielle et la modernisation.",
                "Les épreuves du début du XXe siècle et les grandes crises.",
                "La période contemporaine et les reconstructions.",
                "L'état actuel du sujet : politique, économie et société aujourd'hui.",
                "La culture populaire moderne, les traditions conservées et les clichés.",
                "Anecdotes surprenantes et histoires méconnues liées au sujet.",
                "Les défis futurs, les enjeux écologiques et sociaux à venir.",
                "Bilan global de l'émission, remerciements et mot de la fin chaleureux par $host1 et $host2."
            )

            val fullScript = StringBuilder()
            
            for ((index, section) in sections.withIndex()) {
                val prompt = """
                    Tu animes un long podcast captivant en français avec deux personnes : $host1 (l'animateur) et $host2 (l'experte).
                    Sujet principal : $rawData
                    Étape actuelle du podcast : $section
                    
                    Consignes strictes :
                    1. N'utilise QUE les prénoms $host1 et $host2. Jamais d'autres prénoms, jamais de variables entre crochets.
                    2. Pas de phrase d'introduction générale ("Voici un podcast..."), commence directement par les répliques.
                    3. Pas de Markdown (*, #, _), pas de texte entre parenthèses.
                    4. Format obligatoire de chaque ligne :
                       $host1: [Réplique]
                       $host2: [Réplique]
                    5. ${if (index == 0) "C'est le début de l'émission, $host1 présente le sujet et son invité(e) $host2." else "Continue la discussion de manière fluide dans la même dynamique, sans te réintroduire et en développant le sujet."}
                """.trimIndent()

                val chunk = inference.generateResponse(prompt)

                if (!chunk.isNullOrBlank()) {
                    fullScript.append(chunk).append("\n\n")
                    onProgressUpdate(fullScript.toString())
                }
            }

            return@withContext fullScript.toString()

        } catch (e: Exception) {
            Log.e(TAG, "Erreur de génération", e)
            "Erreur : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}

