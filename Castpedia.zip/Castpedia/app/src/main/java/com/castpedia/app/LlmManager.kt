package com.castpedia.app.ui

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    // URL officielle LiteRT-Community (format .task valide pour Android)
    private const val MODEL_URL = "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/gemma3-1b-it-int4.task"

    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body
                if (body == null) {
                    lastError = "Réponse vide du serveur"
                    return@withContext false
                }

                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet : $total / $expected octets"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Impossible de renommer le fichier temporaire"
                if (tempFile.exists()) tempFile.delete()
                return@withContext false
            }

            Log.d(TAG, "Modèle téléchargé avec succès : ${modelFile.absolutePath}")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Erreur réseau lors du téléchargement", e)
            lastError = "Erreur réseau : ${e.localizedMessage ?: e.javaClass.simpleName}"
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) {
            lastError = "Fichier modèle introuvable dans ${file.absolutePath}"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(1024)
                .setPreferredBackend(LlmInference.Backend.CPU) // Forçage CPU sécurisé
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            Log.d(TAG, "MediaPipe initialisé avec succès sur CPU !")
            return llmInference
        } catch (e: Exception) {
            Log.e(TAG, "Échec de l'initialisation MediaPipe", e)
            lastError = "Erreur MediaPipe : ${e.localizedMessage ?: e.javaClass.simpleName}"
            return null
        }
    }

    suspend fun generatePodcastScript(rawData: String): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: run {
                return@withContext "Erreur d'initialisation : $lastError"
            }
            
            val prompt = "À partir des informations suivantes, rédige un script de podcast captivant et fluide :\n\n$rawData"
            val response = inference.generateResponse(prompt)
            if (response.isNullOrBlank()) "Aucune réponse générée par le modèle." else response
        } catch (e: Exception) {
            Log.e(TAG, "Erreur de génération", e)
            "Erreur de génération : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}

