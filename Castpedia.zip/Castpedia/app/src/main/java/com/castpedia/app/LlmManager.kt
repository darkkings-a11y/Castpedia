
package com.castpedia.app.ui

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

object LlmManager {
    private var llmInference: LlmInference? = null

    // Lien direct public vers un fichier de modèle compatible MediaPipe
    private const val MODEL_URL = "https://huggingface.co/litert-community/Gemma-2b-it-gpu-int4/resolve/main/gemma-2b-it-gpu-int4.bin"
    private const val MODEL_FILENAME = "gemma-3-1b-it.bin"

    var lastError: String = ""

    // Vérifie si le fichier est présent et fait au moins 100 Mo
    fun isModelDownloaded(context: Context): Boolean {
        val file = File(context.filesDir, MODEL_FILENAME)
        return file.exists() && file.length() > 100_000_000
    }

    // Téléchargement automatique avec suivi de la progression en pourcentage
    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val targetFile = File(context.filesDir, MODEL_FILENAME)
        if (isModelDownloaded(context)) return@withContext true

        val client = OkHttpClient.Builder()
            .connectTimeout(120, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        val request = Request.Builder()
            .url(MODEL_URL)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
            .build()

        try {
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                lastError = "Erreur HTTP : ${response.code}"
                targetFile.delete()
                return@withContext false
            }

            val body = response.body ?: return@withContext false
            val fileLength = body.contentLength()
            val inputStream = body.byteStream()
            val outputStream = FileOutputStream(targetFile)

            val buffer = ByteArray(8192)
            var bytesRead: Int
            var totalBytesRead: Long = 0

            while (true) {
                bytesRead = inputStream.read(buffer)
                if (bytesRead == -1) break
                totalBytesRead += bytesRead
                outputStream.write(buffer, 0, bytesRead)

                if (fileLength > 0) {
                    val progress = ((totalBytesRead * 100) / fileLength).toInt()
                    onProgress(progress)
                }
            }

            outputStream.flush()
            outputStream.close()
            inputStream.close()

            return@withContext isModelDownloaded(context)
        } catch (e: Exception) {
            e.printStackTrace()
            lastError = e.localizedMessage ?: "Erreur réseau"
            if (targetFile.exists()) targetFile.delete()
            return@withContext false
        }
    }

    // Initialisation du moteur MediaPipe LLM
    fun initialize(context: Context): Boolean {
        if (llmInference != null) return true

        val modelFile = File(context.filesDir, MODEL_FILENAME)
        if (!modelFile.exists()) return false

        return try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            lastError = "Erreur Init : ${e.localizedMessage}"
            false
        }
    }

    // Génération du script de podcast via l'IA locale
    suspend fun generatePodcastScript(rawApiData: String): String = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            return@withContext "🤖 **Mode Données Brutes** (Modèle non chargé)\n\n$rawApiData"
        }

        val prompt = """
            Tu es un animateur de podcast passionné et dynamique. 
            À partir des informations suivantes, rédige un court script de podcast captivant, fluide et vivant en français :
            
            $rawApiData
        """.trimIndent()

        try {
            return@withContext llmInference?.generateResponse(prompt) ?: "Erreur de génération."
        } catch (e: Exception) {
            return@withContext "Erreur IA : ${e.localizedMessage}"
        }
    }
}
