package com.castpedia.app.ui

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(1024)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Génère le podcast en 12 micro-blocs et met à jour l'UI INSTANTANÉMENT 
     * dès qu'un bloc est terminé grâce au callback `onProgressUpdate`.
     */
    suspend fun generatePodcastScript(
        rawData: String,
        onProgressUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: return@withContext "Erreur d'initialisation : $lastError"

            // Étape 1 : Création du plan en 12 micro-parties
            onProgressUpdate("Création du plan dynamique (12 micro-parties)...")
            val planPrompt = "Agis en tant que producteur de podcast. " +
                    "Crée un plan structuré exactement en 12 micro-chapitres courts et rythmés pour un podcast approfondi sur le sujet : '$rawData'. " +
                    "Donne uniquement la liste des titres sous forme de liste numérotée."
            
            val planResponse = inference.generateResponse(planPrompt)
            if (planResponse.isNullOrBlank()) {
                return@withContext "Erreur : Impossible de générer le plan."
            }

            val chapters = planResponse.lines()
                .filter { it.trim().matches(Regex("^\\d+.*")) }
                .ifEmpty { 
                    listOf(
                        "1. Introduction accrocheuse", 
                        "2. Les racines du sujet", 
                        "3. Le contexte historique", 
                        "4. Les premiers bouleversements",
                        "5. L'expansion et la croissance",
                        "6. Les moments clés et tournants", 
                        "7. Les figures emblématiques", 
                        "8. La vie quotidienne et culture",
                        "9. Les zones d'ombre et paradoxes",
                        "10. L'impact sur le monde moderne",
                        "11. Anecdotes insolites",
                        "12. Conclusion et grand final"
                    ) 
                }

            val fullScript = StringBuilder()
            fullScript.append("# Podcast : $rawData\n\n## Sommaire dynamique\n$planResponse\n\n---\n\n")
            
            // Affichage immédiat du sommaire
            onProgressUpdate(fullScript.toString())

            // Étape 2 : Boucle rapide sur les 12 micro-blocs avec affichage en direct
            for ((index, chapterTitle) in chapters.withIndex()) {
                val currentStep = index + 1
                
                val chapterPrompt = "Tu rédiges une portion courte, dynamique et percutante (style script audio oral) pour le podcast sur : '$rawData'. " +
                        "Rédige uniquement le contenu ciblé de cette partie : '$chapterTitle'."

                val chapterContent = inference.generateResponse(chapterPrompt)

                fullScript.append("## $chapterTitle\n\n")
                if (!chapterContent.isNullOrBlank()) {
                    fullScript.append(chapterContent)
                } else {
                    fullScript.append("[En cours...]\n")
                }
                fullScript.append("\n\n---\n\n")

                // ✨ ENVOI IMMÉDIAT : Le texte accumulé s'affiche à l'écran dès que ce bloc est prêt !
                onProgressUpdate(fullScript.toString())
            }

            return@withContext fullScript.toString()

        } catch (e: Exception) {
            Log.e(TAG, "Erreur de génération", e)
            "Erreur : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}
