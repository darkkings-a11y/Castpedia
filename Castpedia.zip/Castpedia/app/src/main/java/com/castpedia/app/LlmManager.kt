package com.castpedia.app.ui

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LlmManager {
    private var llmInference: LlmInference? = null

    fun initialize(context: Context, modelName: String = "gemma-3-1b-it.bin") {
        if (llmInference != null) return

        try {
            val modelPath = getModelPath(context, modelName)
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelPath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun generatePodcastScript(rawApiData: String): String = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            return@withContext "Modèle LLM non initialisé. Données brutes :\n\n$rawApiData"
        }

        val prompt = """
            Tu es un animateur de podcast passionné et dynamique. 
            À partir des informations suivantes, rédige un court script de podcast captivant, fluide et vivant en français (style conversationnel, prêt à être lu à voix haute) :
            
            $rawApiData
        """.trimIndent()

        try {
            return@withContext llmInference?.generateResponse(prompt) ?: "Erreur de génération."
        } catch (e: Exception) {
            return@withContext "Erreur lors de la génération par l'IA : ${e.localizedMessage}"
        }
    }

    private fun getModelPath(context: Context, modelName: String): String {
        val file = File(context.filesDir, modelName)
        if (!file.exists()) {
            context.assets.open(modelName).use { inputStream ->
                file.outputStream().use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
        }
        return file.absolutePath
    }
}
