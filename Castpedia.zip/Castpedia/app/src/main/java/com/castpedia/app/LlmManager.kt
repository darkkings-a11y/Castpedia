package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Génération d'un podcast à deux voix avec des prénoms aléatoires
     * se présentant au début et dialoguant naturellement.
     */
    suspend fun generatePodcastScript(
        rawData: String,
        onProgressUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: return@withContext "Erreur d'initialisation : $lastError"

            val sections = listOf(
                "Introduction et présentation naturelle des deux animateurs",
                "Contexte historique et origines",
                "Les faits marquants et moments clés",
                "Les enjeux actuels et perspectives d'avenir",
                "Anecdotes et conclusion du podcast"
            )

            val fullScript = StringBuilder()
            
            for ((index, section) in sections.withIndex()) {
                val prompt = """
                    Tu animes un podcast audio en français avec deux personnes (un animateur et un expert).
                    Informations sur le sujet : $rawData
                    Étape actuelle : $section.
                    
                    Consignes strictes :
                    1. Choisis un duo de prénoms (ex: Marc et Julie, Thomas et Sophie, Luc et Élisabeth).
                    2. Pour l'introduction, fais en sorte que l'animateur présente le podcast et son invité(e) de manière naturelle à l'oral.
                    3. Rédige un échange fluide sous forme de dialogue alterné :
                       [Prénom 1]: [Réplique]
                       [Prénom 2]: [Réplique]
                    4. Pas de Markdown (*, #, _), pas de parenthèses ou de voix-off. Uniquement les répliques avec les prénoms au début.
                """.trimIndent()

                val chunk = inference.generateResponse(prompt)

                if (!chunk.isNullOrBlank()) {
                    fullScript.append(chunk).append("\n\n")
                    onProgressUpdate(fullScript.toString())
                }
            }

            return@withContext fullScript.toString()

        } catch (e: Exception) {
            Log.e(TAG, "Erreur de génération", e)
            "Erreur : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}

