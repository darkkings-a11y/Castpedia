
package com.castpedia.app.ui

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur : HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Exception) {
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512) // Réduit pour tester la réactivité
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            return llmInference
        } catch (e: Exception) {
            return null
        }
    }

    /**
     * Test direct ultra-léger sans étape intermédiaire pour vérifier que le CPU répond.
     */
    suspend fun generatePodcastScript(
        rawData: String,
        onProgressUpdate: (String) -> Unit = {}
    ): String = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: return@withContext "Erreur d'initialisation : $lastError"

            onProgressUpdate("Lancement de la génération rapide...")

            // Prompt direct et simple
            val testPrompt = "Présente un podcast audio très court et dynamique sur : '$rawData'."
            
            val response = inference.generateResponse(testPrompt)

            if (response.isNullOrBlank()) {
                return@withContext "Erreur : L'IA n'a renvoyé aucun texte."
            }

            onProgressUpdate(response)
            return@withContext response

        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du test rapide", e)
            "Erreur : ${e.localizedMessage ?: e.javaClass.simpleName}"
        }
    }
}
