package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    private val inferenceMutex = Mutex()

    var lastError: String = "Aucune erreur enregistrée"
        private set

    private val hostPairs = listOf(
        Pair("Thomas", "Julie"),
        Pair("Marc", "Sophie"),
        Pair("Alexandre", "Léa"),
        Pair("Julien", "Camille"),
        Pair("Lucas", "Élodie"),
        Pair("Hugo", "Sarah"),
        Pair("Maxime", "Chloé")
    )

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Échec du renommage du fichier"
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur réseau"}"
            Log.e(TAG, "Erreur téléchargement", e)
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        val fileLength = file.length()
        if (!file.exists() || fileLength == 0L) {
            lastError = "Fichier modèle introuvable"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            if (llmInference == null) {
                lastError = "LlmInference a retourné null"
                file.delete()
            }
            return llmInference
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur d'inférence"}"
            Log.e(TAG, "Erreur initialisation LlmInference", e)
            file.delete()
            return null
        }
    }

    suspend fun generatePodcastStream(
        rawData: String,
        userLanguage: String,
        onBlockGenerated: (host1: String, host2: String, blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference
            if (inference == null) {
                lastError = "Modèle non initialisé"
                return@withContext
            }

            try {
                val randomPair = hostPairs.random()
                val host1 = randomPair.first  // L'Animateur
                val host2 = randomPair.second // L'Expert

                val steps = listOf(
                    "Introduction et première section (génération de l'amorce de l'émission).",
                    "Développement - Section suivante (analyse des faits chronologiques).",
                    "Développement - Section suivante (poursuite du parcours).",
                    "Développement - Section suivante (approfondissement des faits).",
                    "Conclusion de l'émission (résumé synthétique basé uniquement sur les faits présentés)."
                )

                for ((index, stepDescription) in steps.withIndex()) {
                    currentCoroutineContext().ensureActive()

                    onProgressUpdate("Génération - Séquence ${index + 1}/5...")

                    val langInstruction = if (userLanguage == "fr") {
                        "Rédige STRICTEMENT en FRANÇAIS."
                    } else {
                        "Write STRICTLY in English (or user language: $userLanguage)."
                    }

                    val prompt = if (index == 0) {
                        """
                        $langInstruction
                        TU ES UN GÉNÉRATEUR DE PODCAST DOCUMENTAIRE.
                        
                        DONNÉES WIKIPÉDIA OFFICIELLES :
                        $rawData
                        
                        RÈGLES ABSOLUES :
                        - Une seule introduction au début du podcast.
                        - Ne jamais répéter "bonjour" ou "bienvenue".
                        - Ne jamais inventer d'émission, de contexte ou d'informations.
                        - Ne jamais ajouter d'opinion.
                        - Ne jamais dire "merci pour l'invitation".
                        - Ne jamais parler d'informations absentes de Wikipédia.
                        - Ne jamais écrire "voici un podcast" ou "voici un script".
                        - Si une information n'est pas présente dans Wikipédia, ne pas la mentionner. Ne jamais compléter avec les connaissances du modèle.
                        
                        STRUCTURE POUR CETTE INTRODUCTION :
                        $host1: "Bonjour et bienvenue dans ce podcast."
                        Ensuite, $host1 pose la première question sur le début du sujet, et $host2 y répond en se basant uniquement sur le résumé Wikipédia.
                        
                        FORMAT DE SORTIE STRICT :
                        $host1: [Réplique]
                        $host2: [Réplique]
                        Aucun autre texte, aucun titre, aucune numérotation.
                        """.trimIndent()
                    } else {
                        """
                        $langInstruction
                        TU ES UN GÉNÉRATEUR DE PODCAST DOCUMENTAIRE.
                        
                        DONNÉES WIKIPÉDIA OFFICIELLES :
                        $rawData
                        
                        RÈGLES ABSOLUES :
                        - INTERDICTION ABSOLUE de dire "bonjour", "bienvenue" ou de refaire une introduction (le podcast a déjà commencé).
                        - Ne jamais inventer d'informations ou d'opinions.
                        - Suivre strictement la suite des sections Wikipédia dans l'ordre chronologique ($stepDescription).
                        - Si une information n'est pas dans Wikipédia, ne pas la mentionner.
                        
                        STRUCTURE POUR CE BLOC :
                        $host1 pose une question correspondant à la section suivante de Wikipédia.
                        $host2 (l'expert) répond en se basant uniquement sur le contenu de cette section.
                        
                        FORMAT DE SORTIE STRICT :
                        $host1: [Réplique]
                        $host2: [Réplique]
                        Aucun autre texte, aucun titre, aucune numérotation.
                        """.trimIndent()
                    }

                    val chunk = inference.generateResponse(prompt)

                    currentCoroutineContext().ensureActive()

                    if (!chunk.isNullOrBlank()) {
                        onProgressUpdate(chunk)
                        onBlockGenerated(host1, host2, chunk)
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Erreur streaming génération", e)
                lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur"}"
            }
        }
    }
}

