
package com.castpedia.app.ui

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma-2b-it-gpu-int4.bin"
    
    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.0/gemma-2b-it-gpu-int4.bin"

    private var llmInference: LlmInference? = null
    var lastError: String = ""
        private set

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        val file = getModelFile(context)
        return file.exists() && file.length() > 0
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        try {
            if (isModelDownloaded(context)) {
                onProgress(100)
                return@withContext true
            }

            val url = URL(MODEL_URL)
            val connection = url.openConnection() as HttpURLConnection
            
            // Sécurisation de la connexion pour éviter les abandons brusques
            connection.connectTimeout = 15000
            connection.readTimeout = 30000
            connection.instanceFollowRedirects = true
            connection.connect()

            val responseCode = connection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                lastError = "Erreur serveur : Code HTTP $responseCode"
                return@withContext false
            }

            val fileLength = connection.contentLength
            val inputStream = connection.inputStream
            val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

            tempFile.outputStream().use { outputStream ->
                val data = ByteArray(8192)
                var total: Long = 0
                var count: Int
                while (inputStream.read(data).also { count = it } != -1) {
                    total += count.toLong()
                    if (fileLength > 0) {
                        val progress = ((total * 100) / fileLength).toInt()
                        onProgress(progress)
                    }
                    outputStream.write(data, 0, count)
                }
                outputStream.flush()
            }

            inputStream.close()
            connection.disconnect()

            if (tempFile.exists() && tempFile.length() > 0) {
                val modelFile = getModelFile(context)
                if (modelFile.exists()) modelFile.delete()
                tempFile.renameTo(modelFile)
                Log.d(TAG, "Modèle téléchargé avec succès : ${modelFile.absolutePath}")
                true
            } else {
                lastError = "Le fichier téléchargé est vide ou corrompu."
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du téléchargement du modèle", e)
            lastError = e.localizedMessage ?: "Erreur réseau (connexion interrompue)"
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        if (llmInference != null) return llmInference
        if (!isModelDownloaded(context)) {
            lastError = "Le fichier du modèle est introuvable."
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(getModelFile(context).absolutePath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            Log.d(TAG, "MediaPipe LlmInference initialisé avec succès !")
            return llmInference
        } catch (e: Exception) {
            Log.e(TAG, "Échec de l'initialisation de MediaPipe", e)
            lastError = e.localizedMessage ?: "Erreur d'initialisation MediaPipe"
            return null
        }
    }

    suspend fun generatePodcastScript(rawData: String): String = withContext(Dispatchers.IO) {
        try {
            val inference = llmInference ?: run {
                return@withContext "Erreur : Le modèle IA n'est pas initialisé."
            }
            
            val prompt = "À partir des informations suivantes, rédige un script de podcast captivant et fluide :\n\n$rawData"
            val response = inference.generateResponse(prompt)
            response ?: "Aucune réponse générée par le modèle."
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors de la génération du podcast", e)
            "Erreur de génération : ${e.localizedMessage}"
        }
    }
}
