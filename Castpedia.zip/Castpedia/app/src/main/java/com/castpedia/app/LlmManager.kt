package com.darkkings.castpedia.app // Mets exactement le même package que ton MainScreen.kt

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class LlmManager(private val context: Context) {

    companion object {
        private const val TAG = "LlmManager"
        private const val MODEL_NAME = "gemma-2b-it-gpu-int4.bin"
        
        // Ton URL directe publique hébergée sur ta Release GitHub
        private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.0/gemma-2b-it-gpu-int4.bin"
    }

    private var llmInference: LlmInference? = null

    /**
     * Fichier cible dans le stockage interne de l'application
     */
    val modelFile: File
        get() = File(context.filesDir, MODEL_NAME)

    /**
     * Vérifie si le modèle est déjà présent et non vide
     */
    fun isModelDownloaded(): Boolean {
        return modelFile.exists() && modelFile.length() > 0
    }

    /**
     * Télécharge le modèle depuis GitHub avec un callback de progression (0 à 100%)
     */
    suspend fun downloadModel(onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        try {
            if (isModelDownloaded()) {
                onProgress(100)
                return@withContext true
            }

            val url = URL(MODEL_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.connect()

            val fileLength = connection.contentLength
            val inputStream = connection.inputStream
            val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

            tempFile.outputStream().use { outputStream ->
                val data = ByteArray(8192)
                var total: Long = 0
                var count: Int
                while (inputStream.read(data).also { count = it } != -1) {
                    total += count.toLong()
                    if (fileLength > 0) {
                        val progress = ((total * 100) / fileLength).toInt()
                        onProgress(progress)
                    }
                    outputStream.write(data, 0, count)
                }
                outputStream.flush()
            }

            inputStream.close()
            connection.disconnect()

            // Remplacement sécurisé du fichier temporaire par le fichier final
            if (tempFile.exists()) {
                if (modelFile.exists()) modelFile.delete()
                tempFile.renameTo(modelFile)
                Log.d(TAG, "Modèle téléchargé avec succès : ${modelFile.absolutePath}")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur lors du téléchargement du modèle", e)
            false
        }
    }

    /**
     * Initialise MediaPipe LlmInference à partir du fichier téléchargé
     */
    fun initializeLlm(): LlmInference? {
        if (llmInference != null) return llmInference
        if (!isModelDownloaded()) return null

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .build()

            llmInference = LlmInference.createFromContext(context, options)
            Log.d(TAG, "MediaPipe LlmInference initialisé avec succès !")
            return llmInference
        } catch (e: Exception) {
            Log.e(TAG, "Échec de l'initialisation de MediaPipe LlmInference", e)
            return null
        }
    }
}

