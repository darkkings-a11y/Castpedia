package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    private val inferenceMutex = Mutex()

    var lastError: String = "Aucune erreur enregistrée"
        private set

    private val hostPairs = listOf(
        Pair("Thomas", "Julie"),
        Pair("Marc", "Sophie"),
        Pair("Alexandre", "Léa"),
        Pair("Julien", "Camille"),
        Pair("Lucas", "Élodie"),
        Pair("Hugo", "Sarah"),
        Pair("Maxime", "Chloé")
    )

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Échec du renommage du fichier"
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur réseau"}"
            Log.e(TAG, "Erreur téléchargement", e)
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        val fileLength = file.length()
        if (!file.exists() || fileLength == 0L) {
            lastError = "Fichier modèle introuvable"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            if (llmInference == null) {
                lastError = "LlmInference a retourné null"
                file.delete()
            }
            return llmInference
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur d'inférence"}"
            Log.e(TAG, "Erreur initialisation LlmInference", e)
            file.delete()
            return null
        }
    }

    suspend fun generatePodcastStream(
        rawData: String,
        userLanguage: String,
        onBlockGenerated: (host1: String, host2: String, blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        inferenceMutex.withLock {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference
            if (inference == null) {
                lastError = "Modèle non initialisé"
                return@withContext
            }

            try {
                val randomPair = hostPairs.random()
                val host1 = randomPair.first  // L'Animateur
                val host2 = randomPair.second // L'Expert

                val phases = listOf(
                    "1. Introduction : Présente le sujet en suivant le résumé introductif de l'article.",
                    "2. Développement - Partie 1 : Parle des premières sections principales (H2/H3) dans l'ordre exact de Wikipédia.",
                    "3. Développement - Partie 2 : Poursuit les sections suivantes en conservant le fil chronologique.",
                    "4. Développement - Partie 3 : Aborde les sections avancées ou de maturité du sujet.",
                    "5. Conclusion : Fait un court résumé synthétique des informations présentées, sans ajouter de nouvelles informations."
                )

                for ((index, phase) in phases.withIndex()) {
                    currentCoroutineContext().ensureActive()

                    onProgressUpdate("Génération - Séquence ${index + 1}/5...")

                    val langInstruction = if (userLanguage == "fr") {
                        "Rédige STRICTEMENT en FRANÇAIS."
                    } else {
                        "Write STRICTLY in English (or user language: $userLanguage)."
                    }

                    val prompt = """
                        $langInstruction
                        Tu produis un script de podcast à deux voix entre l'Animateur ($host1) et l'Expert ($host2).
                        
                        STRUCTURE WIKIPÉDIA OFFICIELLE (À RESPECTER STRICTEMENT DANS L'ORDRE) :
                        $rawData
                        
                        OBJECTIF DE CETTE SÉQUENCE : $phase
                        
                        RÈGLES D'OR ABSOLUES :
                        1. $host1 (l'animateur) pose les questions ou lance les thèmes en référence directe avec la structure Wikipédia fournie.
                        2. $host2 (l'expert) répond en s'appuyant rigoureusement sur le contenu textuel Wikipédia.
                        3. INTERDICTION FORMELLE d'inventer, d'halluciner ou de modifier l'ordre des sections. Suis le chemin de lecture encyclopédique.
                        4. ZÉRO BLABLA INUTILE : pas de salutations répétitives, va droit aux faits.
                        5. Format obligatoire :
                           $host1: [Réplique]
                           $host2: [Réplique]
                    """.trimIndent()

                    val chunk = inference.generateResponse(prompt)

                    currentCoroutineContext().ensureActive()

                    if (!chunk.isNullOrBlank()) {
                        onProgressUpdate(chunk)
                        onBlockGenerated(host1, host2, chunk)
                    }
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Erreur streaming génération", e)
                lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur"}"
            }
        }
    }
}

