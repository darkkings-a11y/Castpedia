package com.castpedia.app

import android.content.Context
import android.util.Log
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object LlmManager {
    private const val TAG = "LlmManager"
    private const val MODEL_NAME = "gemma3-1b-it-int4.task"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.1/gemma3-1b-it-int4.task"
    private val OLD_MODELS = listOf("gemma-2b-it-gpu-int4.bin", "gemma3-1b-it-int8-web.task")

    private var llmInference: LlmInference? = null
    private var appContext: Context? = null
    var lastError: String = "Aucune erreur enregistrée"
        private set

    private val hostPairs = listOf(
        Pair("Thomas", "Julie"),
        Pair("Marc", "Sophie"),
        Pair("Alexandre", "Léa"),
        Pair("Julien", "Camille"),
        Pair("Lucas", "Élodie"),
        Pair("Hugo", "Sarah"),
        Pair("Maxime", "Chloé")
    )

    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_NAME)
    }

    fun isModelDownloaded(context: Context): Boolean {
        OLD_MODELS.forEach { File(context.filesDir, it).delete() }
        val file = getModelFile(context)
        return file.exists() && file.length() > 1024 * 1024
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        appContext = context.applicationContext
        val modelFile = getModelFile(context)
        val tempFile = File(context.filesDir, "$MODEL_NAME.tmp")

        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(MODEL_URL)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur serveur HTTP ${response.code}"
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (total == 0L || (expected > 0 && total != expected)) {
                    lastError = "Téléchargement incomplet"
                    tempFile.delete()
                    return@withContext false
                }
            }

            if (modelFile.exists()) modelFile.delete()
            if (!tempFile.renameTo(modelFile)) {
                lastError = "Échec du renommage du fichier"
                tempFile.delete()
                return@withContext false
            }
            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur réseau"}"
            Log.e(TAG, "Erreur téléchargement", e)
            if (tempFile.exists()) tempFile.delete()
            false
        }
    }

    fun initialize(context: Context): LlmInference? {
        appContext = context.applicationContext
        if (llmInference != null) return llmInference
        
        val file = getModelFile(context)
        if (!file.exists() || file.length() == 0L) {
            lastError = "Fichier modèle introuvable"
            return null
        }

        try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(file.absolutePath)
                .setMaxTokens(512)
                .setPreferredBackend(LlmInference.Backend.CPU)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            if (llmInference == null) {
                lastError = "LlmInference a retourné null"
                file.delete()
            }
            return llmInference
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur d'inférence"}"
            Log.e(TAG, "Erreur initialisation LlmInference", e)
            file.delete()
            return null
        }
    }

    suspend fun generatePodcastStream(
        rawData: String,
        onBlockGenerated: (host1: String, host2: String, blockText: String) -> Unit,
        onProgressUpdate: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            if (llmInference == null && appContext != null) {
                initialize(appContext!!)
            }

            val inference = llmInference ?: return@withContext

            val randomPair = hostPairs.random()
            val host1 = randomPair.first
            val host2 = randomPair.second

            val sections = listOf(
                "Introduction générale : $host1 accueille $host2, présentent le sujet et lancent l'émission.",
                "Origines lointaines et premières traces dans l'histoire.",
                "Les mythes fondateurs et légendes populaires.",
                "L'Antiquité et la structuration des communautés.",
                "Les grandes figures historiques de la première époque.",
                "L'organisation sociale et la vie quotidienne d'autrefois.",
                "Les premiers grands événements majeurs et tournants historiques.",
                "Les guerres, batailles ou révolutions marquantes.",
                "L'évolution de la politique et des lois d'autrefois.",
                "L'âge d'or culturel, les arts et la pensée.",
                "Les relations avec les voisins et influences extérieures.",
                "Les grandes découvertes et innovations économiques.",
                "La transition vers l'ère moderne et industrielle.",
                "Les épreuves du XXe siècle et les crises traversées.",
                "La période contemporaine et les reconstructions.",
                "L'état actuel du sujet : politique, économie et société aujourd'hui.",
                "La culture populaire moderne et les traditions conservées.",
                "Anecdotes surprenantes et histoires méconnues.",
                "Les défis futurs et les enjeux à venir.",
                "Bilan global de l'émission, remerciements et mot de la fin chaleureux par $host1 et $host2."
            )

            for ((index, section) in sections.withIndex()) {
                onProgressUpdate("Génération du bloc ${index + 1}/20...")

                val prompt = """
                    Tu animes un long podcast captivant en français avec deux personnes : $host1 (l'animateur) et $host2 (l'experte).
                    Sujet principal : $rawData
                    Étape actuelle du podcast : $section
                    
                    CONSIGNES STRICTES DE LANGUE ET DE FORMAT :
                    1. Français absolument parfait, orthographe rigoureuse, grammaire irréprochable (pas de fautes de frappe, respecte scrupuleusement l'orthographe des mots comme "cette", "leur", etc.).
                    2. N'utilise QUE les prénoms $host1 et $host2 au format strict "Nom: Réplique". Jamais d'autres prénoms.
                    3. AUCUN horodatage, AUCUNE balise de temps (pas de [00:00], pas de crochets, pas d'astérisques *). Uniquement du texte parlé brut.
                    4. Pas de phrase d'introduction générale, commence directement par les répliques.
                    5. Format obligatoire de chaque ligne :
                       $host1: [Réplique]
                       $host2: [Réplique]
                    6. ${if (index == 0) "C'est le début de l'émission, $host1 présente le sujet et son invité(e) $host2." else "Continue la discussion de manière fluide dans la même dynamique, sans te réintroduire."}
                """.trimIndent()

                val chunk = inference.generateResponse(prompt)

                if (!chunk.isNullOrBlank()) {
                    onProgressUpdate(chunk)
                    onBlockGenerated(host1, host2, chunk)
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Erreur streaming génération", e)
            lastError = "${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message ?: "Erreur"}"
        }
    }
}

