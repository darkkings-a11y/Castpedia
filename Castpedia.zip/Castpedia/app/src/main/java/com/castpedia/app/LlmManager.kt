package com.castpedia.app.ui

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

object LlmManager {
    private var llmInference: LlmInference? = null
    private const val MODEL_FILENAME = "gemma-3-1b-it.bin"
    var lastError: String = ""

    fun isModelDownloaded(context: Context): Boolean {
        val file = File(context.filesDir, MODEL_FILENAME)
        return file.exists() && file.length() > 100_000_000
    }

    suspend fun downloadModel(context: Context, onProgress: (Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        // Pour l'instant, on simule ou on évite le blocage si le lien direct nécessite une auth
        // L'app fonctionnera avec les superbes données multi-API en attendant d'intégrer le fichier local manuellement si besoin.
        false 
    }

    fun initialize(context: Context): Boolean {
        if (llmInference != null) return true
        val modelFile = File(context.filesDir, MODEL_FILENAME)
        if (!modelFile.exists()) return false

        return try {
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(512)
                .setTemperature(0.7f)
                .setTopK(40)
                .build()

            llmInference = LlmInference.createFromOptions(context, options)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun generatePodcastScript(rawApiData: String): String = withContext(Dispatchers.IO) {
        if (llmInference == null) {
            return@withContext "🤖 **Mode Synthèse Directe (API)**\n\nVoici les informations collectées pour ton sujet :\n\n$rawApiData"
        }

        val prompt = """
            Tu es un animateur de podcast passionné et dynamique. 
            À partir des informations suivantes, rédige un court script de podcast captivant, fluide et vivant en français :
            
            $rawApiData
        """.trimIndent()

        try {
            return@withContext llmInference?.generateResponse(prompt) ?: rawApiData
        } catch (e: Exception) {
            return@withContext rawApiData
        }
    }
}

