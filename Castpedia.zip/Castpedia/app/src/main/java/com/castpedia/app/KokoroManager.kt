package com.castpedia.app

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import javax.net.ssl.HttpsURLConnection

object KokoroManager {

    private const val MODEL_FILENAME = "kokoro-v1.0.int8.onnx"
    private const val VOICES_FILENAME = "voices-v1.0.bin"

    // Tes liens de releases GitHub officiels
    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.4/kokoro-v1.0.int8.onnx"
    private const val VOICES_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.5/voices-v1.0.bin"

    /**
     * Renvoie le fichier local du modèle Kokoro dans le stockage interne de l'app.
     */
    fun getModelFile(context: Context): File {
        return File(context.filesDir, MODEL_FILENAME)
    }

    /**
     * Renvoie le fichier local de la banque de voix.
     */
    fun getVoicesFile(context: Context): File {
        return File(context.filesDir, VOICES_FILENAME)
    }

    /**
     * Vérifie si le modèle et les voix sont présents et valides.
     */
    fun areFilesDownloaded(context: Context): Boolean {
        val modelFile = getModelFile(context)
        val voicesFile = getVoicesFile(context)
        return modelFile.exists() && modelFile.length() > 0L &&
               voicesFile.exists() && voicesFile.length() > 0L
    }

    /**
     * Télécharge le modèle et les voix depuis GitHub en arrière-plan.
     */
    suspend fun downloadFiles(
        context: Context,
        onProgress: (statusMessage: String, progress: Float) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val modelFile = getModelFile(context)
            if (!modelFile.exists() || modelFile.length() == 0L) {
                onProgress("Téléchargement du modèle Kokoro...", 0f)
                downloadFileWithProgress(MODEL_URL, modelFile) { progress ->
                    onProgress("Téléchargement du modèle Kokoro (${(progress * 100).toInt()}%)", progress)
                }
            }

            val voicesFile = getVoicesFile(context)
            if (!voicesFile.exists() || voicesFile.length() == 0L) {
                onProgress("Téléchargement de la banque de voix...", 0f)
                downloadFileWithProgress(VOICES_URL, voicesFile) { progress ->
                    onProgress("Téléchargement de la banque de voix (${(progress * 100).toInt()}%)", progress)
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun downloadFileWithProgress(urlString: String, outputFile: File, onProgress: (Float) -> Unit) {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpsURLConnection
        connection.connect()

        val fileLength = connection.contentLength.toFloat()
        connection.inputStream.use { input ->
            FileOutputStream(outputFile).use { output ->
                val buffer = ByteArray(8192)
                var bytesRead: Int
                var totalBytesRead = 0f

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    output.write(buffer, 0, bytesRead)
                    totalBytesRead += bytesRead
                    if (fileLength > 0f) {
                        onProgress(totalBytesRead / fileLength)
                    }
                }
                output.flush()
            }
        }
        connection.disconnect()
    }
}

