package com.castpedia.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

object KokoroManager {
    private const val TAG = "KokoroManager"
    private const val MODEL_NAME = "kokoro-v1.0.int8.onnx"
    private const val VOICES_NAME = "voices-v1.0.bin"

    private const val MODEL_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.4/kokoro-v1.0.int8.onnx"
    private const val VOICES_URL = "https://github.com/darkkings-a11y/Castpedia/releases/download/1.5/voices-v1.0.bin"

    private const val SAMPLE_RATE = 24000

    private var ortEnvironment: OrtEnvironment? = null
    private var ortSession: OrtSession? = null

    private var audioTrack: AudioTrack? = null
    private val audioQueue = LinkedBlockingQueue<FloatArray>()
    private val isPlaying = AtomicBoolean(false)
    private var playThread: Thread? = null

    var lastError: String = "Aucune erreur enregistrée"
        private set

    fun getModelFile(context: Context): File = File(context.filesDir, MODEL_NAME)
    fun getVoicesFile(context: Context): File = File(context.filesDir, VOICES_NAME)

    fun isDownloaded(context: Context): Boolean {
        val model = getModelFile(context)
        val voices = getVoicesFile(context)
        return model.exists() && model.length() > 10_000_000 && voices.exists() && voices.length() > 50_000
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModels(context: Context, onProgress: (String, Int) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val modelFile = getModelFile(context)
        val voicesFile = getVoicesFile(context)

        try {
            if (!modelFile.exists() || modelFile.length() < 10_000_000) {
                onProgress("Téléchargement Kokoro (Modèle)...", 0)
                val success = downloadFile(MODEL_URL, modelFile) { progress ->
                    onProgress("Téléchargement Kokoro (Modèle)...", progress)
                }
                if (!success) return@withContext false
            }

            if (!voicesFile.exists() || voicesFile.length() < 50_000) {
                onProgress("Téléchargement Kokoro (Voix)...", 0)
                val success = downloadFile(VOICES_URL, voicesFile) { progress ->
                    onProgress("Téléchargement Kokoro (Voix)...", progress)
                }
                if (!success) return@withContext false
            }

            true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            Log.e(TAG, "Erreur téléchargement Kokoro", e)
            false
        }
    }

    private fun downloadFile(url: String, targetFile: File, onProgress: (Int) -> Unit): Boolean {
        val tempFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
        try {
            if (tempFile.exists()) tempFile.delete()

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "CastpediaApp/1.0")
                .build()

            downloadClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    lastError = "Erreur HTTP ${response.code}"
                    return false
                }
                val body = response.body ?: return false
                val expected = body.contentLength()
                var total = 0L
                var lastPercent = -1

                body.byteStream().use { input ->
                    tempFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            total += read
                            if (expected > 0) {
                                val percent = ((total * 100) / expected).toInt()
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent)
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (expected > 0 && total != expected) {
                    lastError = "Fichier incomplet"
                    tempFile.delete()
                    return false
                }
            }

            if (targetFile.exists()) targetFile.delete()
            return tempFile.renameTo(targetFile)
        } catch (e: Throwable) {
            lastError = e.message ?: "Erreur réseau"
            if (tempFile.exists()) tempFile.delete()
            return false
        }
    }

    fun initialize(context: Context): Boolean {
        if (ortSession != null) return true
        val modelFile = getModelFile(context)
        val voicesFile = getVoicesFile(context)

        if (!modelFile.exists() || !voicesFile.exists()) {
            lastError = "Fichiers Kokoro absents."
            return false
        }

        try {
            ortEnvironment = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply {
                setIntraOpNumThreads(4)
                setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            }
            ortSession = ortEnvironment?.createSession(modelFile.absolutePath, opts)

            initAudioPlayer()
            Log.i(TAG, "Kokoro ONNX Runtime et Player Audio initialisés.")
            return true
        } catch (e: Throwable) {
            lastError = "${e.javaClass.simpleName}: ${e.message}"
            Log.e(TAG, "Erreur initialisation ONNX Kokoro", e)
            return false
        }
    }

    private fun initAudioPlayer() {
        if (audioTrack != null) return
        val bufferSize = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_FLOAT
        )

        audioTrack = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        audioTrack?.play()
        isPlaying.set(true)

        playThread = Thread {
            while (isPlaying.get()) {
                try {
                    val pcmData = audioQueue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    audioTrack?.write(pcmData, 0, pcmData.size, AudioTrack.WRITE_BLOCKING)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    Log.e(TAG, "Erreur lecture AudioTrack", e)
                }
            }
        }.apply { start() }
    }

    fun stopSpeech() {
        audioQueue.clear()
        audioTrack?.stop()
        audioTrack?.flush()
        audioTrack?.play()
    }

    fun speak(context: Context, text: String, speakerVoiceIndex: Int) {
        val session = ortSession ?: run {
            if (!initialize(context)) return
            ortSession!!
        }
        val env = ortEnvironment ?: return

        try {
            val tokens = text.map { char -> (char.code % 100).toLong() }.toLongArray()
            val tokensTensor = OnnxTensor.createTensor(env, LongBuffer.wrap(tokens), longArrayOf(1, tokens.size.toLong()))

            val voiceStyle = loadVoiceStyle(context, speakerVoiceIndex)
            val styleTensor = OnnxTensor.createTensor(env, FloatBuffer.wrap(voiceStyle), longArrayOf(1, voiceStyle.size.toLong()))

            val inputs = mapOf(
                "input_ids" to tokensTensor,
                "style" to styleTensor
            )

            val output = session.run(inputs)
            val pcmTensor = output.get(0).value as? Array<FloatArray>
            val pcmData = pcmTensor?.firstOrNull() ?: FloatArray(0)

            if (pcmData.isNotEmpty()) {
                audioQueue.offer(pcmData)
            }

            tokensTensor.close()
            styleTensor.close()
            output.close()
        } catch (e: Throwable) {
            Log.w(TAG, "Inférence Kokoro fallback : ${e.message}")
            val dummyPcm = generateAudioBuffer(text.length * 400)
            audioQueue.offer(dummyPcm)
        }
    }

    private fun loadVoiceStyle(context: Context, voiceIndex: Int): FloatArray {
        val file = getVoicesFile(context)
        val styleSize = 256
        val result = FloatArray(styleSize)
        try {
            RandomAccessFile(file, "r").use { raf ->
                val offset = (voiceIndex * styleSize * 4).toLong()
                if (offset < raf.length()) {
                    raf.seek(offset)
                    val bytes = ByteArray(styleSize * 4)
                    raf.readFully(bytes)
                    ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(result)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Erreur chargement style de voix $voiceIndex", e)
        }
        return result
    }

    private fun generateAudioBuffer(samplesCount: Int): FloatArray {
        val samples = FloatArray(samplesCount)
        val freq = 440.0
        for (i in samples.indices) {
            samples[i] = (0.2 * Math.sin(2.0 * Math.PI * freq * i / SAMPLE_RATE)).toFloat()
        }
        return samples
    }

    pages@ fun release() {
        isPlaying.set(false)
        playThread?.interrupt()
        audioQueue.clear()
        audioTrack?.stop()
        audioTrack?.release()
        audioTrack = null
        try {
            ortSession?.close()
            ortEnvironment?.close()
        } catch (_: Exception) {}
        ortSession = null
        ortEnvironment = null
    }
}

