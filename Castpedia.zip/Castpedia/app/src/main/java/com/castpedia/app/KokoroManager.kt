package com.castpedia.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/**
 * VERSION TEMPORAIRE : utilise la voix du système Android (TextToSpeech) pour avoir du son
 * tout de suite. Le nom KokoroManager est conservé pour ne rien changer dans MainScreen.kt.
 * L'ancien code Kokoro (ONNX) est à remettre plus tard, avec un vrai phonémiseur.
 */
object KokoroManager {
    private const val TAG = "KokoroManager"

    private var tts: TextToSpeech? = null
    private var starting = false
    private var ready = false
    private val pending = mutableListOf<Pair<String, Int>>()
    private val lock = Any()
    private val counter = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    var lastError: String = "Aucune erreur enregistrée"
        private set

    // Gardés pour compatibilité (plus de téléchargement Kokoro pour l'instant)
    fun getModelFile(context: Context): File = File(context.filesDir, "kokoro-v1.0.int8.onnx")
    fun getVoicesFile(context: Context): File = File(context.filesDir, "voices-v1.0.bin")

    fun isDownloaded(context: Context): Boolean = true

    @Suppress("UNUSED_PARAMETER")
    suspend fun downloadModels(context: Context, onProgress: (String, Int) -> Unit): Boolean = true

    fun initialize(context: Context): Boolean {
        val app = context.applicationContext
        synchronized(lock) {
            if (tts != null || starting) return true
            starting = true
        }
        // TextToSpeech doit être créé depuis le thread principal
        mainHandler.post {
            tts = TextToSpeech(app) { status -> onTtsInit(status) }
        }
        return true
    }

    private fun onTtsInit(status: Int) {
        val engine = tts
        if (status != TextToSpeech.SUCCESS || engine == null) {
            lastError = "Initialisation TextToSpeech échouée (code $status)"
            Log.e(TAG, lastError)
            return
        }

        val result = engine.setLanguage(Locale.getDefault())
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            lastError = "Langue ${Locale.getDefault()} indisponible dans le moteur vocal"
            Log.w(TAG, lastError)
        }
        engine.setSpeechRate(1.0f)

        val toSpeak = synchronized(lock) {
            ready = true
            val copy = pending.toList()
            pending.clear()
            copy
        }
        toSpeak.forEach { (text, voice) -> speakNow(text, voice) }
    }

    private fun speakNow(text: String, voiceIndex: Int) {
        val engine = tts ?: return
        // Deux "voix" : l'expert a une voix un peu plus grave
        engine.setPitch(if (voiceIndex == 0) 1.0f else 0.8f)
        val res = engine.speak(
            text,
            TextToSpeech.QUEUE_ADD,
            null,
            "castpedia-${counter.incrementAndGet()}"
        )
        if (res != TextToSpeech.SUCCESS) {
            lastError = "TextToSpeech.speak a échoué (code $res)"
            Log.e(TAG, lastError)
        }
    }

    fun speak(context: Context, text: String, speakerVoiceIndex: Int) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        initialize(context)

        val readyNow = synchronized(lock) {
            if (!ready) {
                pending.add(clean to speakerVoiceIndex)
                false
            } else {
                true
            }
        }
        if (readyNow) speakNow(clean, speakerVoiceIndex)
    }

    fun stopSpeech() {
        synchronized(lock) { pending.clear() }
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    fun release() {
        synchronized(lock) {
            pending.clear()
            ready = false
            starting = false
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }
}

