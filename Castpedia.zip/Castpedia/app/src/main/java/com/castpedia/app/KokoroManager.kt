package com.castpedia.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.Log
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Voix Kokoro via sherpa-onnx (phonémisation espeak-ng incluse).
 * Si Kokoro n'est pas prêt ou échoue, on retombe sur la voix système Android
 * pour ne jamais se retrouver sans son.
 * Le nom de l'objet reste KokoroManager pour ne rien changer dans MainScreen.kt.
 */
object KokoroManager {
    private const val TAG = "KokoroManager"

    private const val MODEL_URL =
        "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-int8-multi-lang-v1_0.tar.bz2"

    // Numéros de voix dans le fichier voices.bin de sherpa-onnx (kokoro-multi-lang-v1_0)
    private const val SID_FR = 30        // ff_siwis (la seule voix française)
    private const val SID_EN_F = 3       // af_heart
    private const val SID_EN_M = 11      // am_adam
    private const val SID_ES_F = 28      // ef_dora
    private const val SID_ES_M = 29      // em_alex
    private const val SID_IT_F = 35      // if_sara
    private const val SID_IT_M = 36      // im_nicola
    private const val SID_PT_F = 42      // pf_dora
    private const val SID_PT_M = 43      // pm_alex

    var lastError: String = "Aucune erreur enregistrée"
        private set

    // ---------- Kokoro ----------
    @Volatile private var engine: OfflineTts? = null
    private var audioTrack: AudioTrack? = null
    private val queue = LinkedBlockingQueue<Pair<String, Int>>()
    private var synthThread: Thread? = null
    private var playThread: Thread? = null
    private class AudioChunk(val samples: FloatArray, val gen: Int)
    private val audioQueue = LinkedBlockingQueue<AudioChunk>()
    @Volatile private var running = false
    @Volatile private var synthBusy = false
    @Volatile private var playing = false
    private val generation = AtomicInteger(0)

    private data class VoiceSet(val lang: String, val sid0: Int, val sid1: Int)

    private fun voiceSet(): VoiceSet = when (Locale.getDefault().language) {
        "fr" -> VoiceSet("fr", SID_FR, SID_FR)
        "es" -> VoiceSet("es", SID_ES_F, SID_ES_M)
        "it" -> VoiceSet("it", SID_IT_F, SID_IT_M)
        "pt" -> VoiceSet("pt-br", SID_PT_F, SID_PT_M)
        else -> VoiceSet("en-us", SID_EN_F, SID_EN_M)
    }

    private fun modelDir(context: Context) = File(context.filesDir, "kokoro-sherpa")

    fun isDownloaded(context: Context): Boolean {
        val dir = modelDir(context)
        return File(dir, ".complete").exists() &&
            File(dir, "model.int8.onnx").length() > 50_000_000 &&
            File(dir, "voices.bin").exists() &&
            File(dir, "tokens.txt").exists() &&
            File(dir, "espeak-ng-data/phondata").exists()
    }

    private val downloadClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    suspend fun downloadModels(context: Context, onProgress: (String, Int) -> Unit): Boolean =
        withContext(Dispatchers.IO) {
            val dir = modelDir(context)
            val tarFile = File(context.filesDir, "kokoro-sherpa.tar.bz2.tmp")
            try {
                dir.deleteRecursively()
                tarFile.delete()

                val msgDl = "Téléchargement des voix Kokoro..."
                onProgress(msgDl, 0)
                val request = Request.Builder()
                    .url(MODEL_URL)
                    .header("User-Agent", "CastpediaApp/1.0")
                    .build()

                downloadClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        lastError = "Téléchargement Kokoro : erreur HTTP ${response.code}"
                        return@withContext false
                    }
                    val body = response.body
                    if (body == null) {
                        lastError = "Téléchargement Kokoro : réponse vide"
                        return@withContext false
                    }
                    val expected = body.contentLength()
                    var total = 0L
                    var lastPct = -1
                    body.byteStream().use { input ->
                        tarFile.outputStream().use { output ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read == -1) break
                                output.write(buffer, 0, read)
                                total += read
                                if (expected > 0) {
                                    val pct = ((total * 100) / expected).toInt()
                                    if (pct != lastPct) {
                                        lastPct = pct
                                        onProgress(msgDl, pct)
                                    }
                                }
                            }
                            output.flush()
                        }
                    }
                    if (total == 0L || (expected > 0 && total != expected)) {
                        lastError = "Téléchargement Kokoro incomplet"
                        return@withContext false
                    }
                }

                val msgInstall = "Installation des voix Kokoro..."
                onProgress(msgInstall, 0)
                extractTarBz2(tarFile, dir) { pct -> onProgress(msgInstall, pct) }
                File(dir, ".complete").writeText("ok")
                true
            } catch (e: Throwable) {
                lastError = "Installation Kokoro : ${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message}"
                Log.e(TAG, "Erreur téléchargement/installation Kokoro", e)
                dir.deleteRecursively()
                false
            } finally {
                tarFile.delete()
            }
        }

    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        @Volatile var count = 0L
        override fun read(): Int {
            val b = super.read()
            if (b >= 0) count++
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val n = super.read(b, off, len)
            if (n > 0) count += n
            return n
        }
    }

    // On ne garde pas ce qui sert au chinois (inutile pour Castpedia)
    private fun shouldKeep(rel: String): Boolean {
        if (rel.startsWith("dict/")) return false
        if (rel.startsWith("lexicon")) return false
        if (rel.endsWith(".fst")) return false
        return true
    }

    private fun extractTarBz2(tarFile: File, destDir: File, onProgress: (Int) -> Unit) {
        destDir.mkdirs()
        val destCanonical = destDir.canonicalPath
        val totalBytes = tarFile.length().coerceAtLeast(1L)
        val counting = CountingInputStream(BufferedInputStream(FileInputStream(tarFile), 256 * 1024))

        TarArchiveInputStream(BZip2CompressorInputStream(counting)).use { tar ->
            var lastPct = -1
            @Suppress("DEPRECATION")
            var entry = tar.nextTarEntry
            while (entry != null) {
                // On enlève le dossier racine de l'archive
                val rel = entry.name.substringAfter('/', "")
                if (rel.isNotEmpty() && !entry.isDirectory && shouldKeep(rel)) {
                    val outFile = File(destDir, rel)
                    if (!outFile.canonicalPath.startsWith(destCanonical + File.separator)) {
                        throw IOException("Chemin invalide dans l'archive : ${entry.name}")
                    }
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { out -> tar.copyTo(out) }
                }
                val pct = ((counting.count * 100) / totalBytes).toInt().coerceIn(0, 100)
                if (pct != lastPct) {
                    lastPct = pct
                    onProgress(pct)
                }
                entry = tar.nextTarEntry
            }
        }
    }

    @Synchronized
    fun initialize(context: Context): Boolean {
        initFallback(context)
        if (engine != null) return true
        if (!isDownloaded(context)) {
            lastError = "Voix Kokoro non installées"
            return false
        }
        return try {
            val d = modelDir(context).absolutePath
            val kokoro = OfflineTtsKokoroModelConfig(
                model = "$d/model.int8.onnx",
                voices = "$d/voices.bin",
                tokens = "$d/tokens.txt",
                dataDir = "$d/espeak-ng-data",
                lexicon = "",
                lang = voiceSet().lang
            )
            val config = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    kokoro = kokoro,
                    numThreads = 4,
                    debug = false,
                    provider = "cpu"
                )
            )
            val tts = OfflineTts(assetManager = null, config = config)
            startPlayback(tts.sampleRate())
            engine = tts
            Log.i(TAG, "Kokoro (sherpa-onnx) initialisé, langue ${voiceSet().lang}")
            true
        } catch (e: Throwable) {
            lastError = "Init Kokoro : ${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message}"
            Log.e(TAG, "Erreur init Kokoro", e)
            false
        }
    }

    private fun startPlayback(sampleRate: Int) {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
        )
        val bufferBytes = if (minBuf > 0) minBuf * 2 else sampleRate * 4

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferBytes)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        audioTrack = track

        running = true

        // Thread 1 : synthèse (prépare les phrases suivantes pendant que la phrase actuelle est lue)
        synthThread = Thread {
            while (running) {
                val item: Pair<String, Int>? = try {
                    queue.poll(300, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    null
                }
                if (item == null) {
                    if (!running) break else continue
                }

                val myGeneration = generation.get()
                synthBusy = true
                try {
                    val (text, voiceIndex) = item
                    val set = voiceSet()
                    val sid = if (voiceIndex == 0) set.sid0 else set.sid1
                    val speed = if (voiceIndex == 0) 1.0f else 0.93f
                    val audio = engine?.generate(text = text, sid = sid, speed = speed)
                    if (audio != null && audio.samples.isNotEmpty() && generation.get() == myGeneration) {
                        audioQueue.offer(AudioChunk(audio.samples, myGeneration))
                    }
                } catch (e: Throwable) {
                    lastError = "Synthèse Kokoro : ${e.javaClass.simpleName}: ${e.localizedMessage ?: e.message}"
                    Log.e(TAG, "Erreur synthèse Kokoro", e)
                } finally {
                    synthBusy = false
                }
            }
        }.apply {
            isDaemon = true
            start()
        }

        // Thread 2 : lecture (joue les phrases déjà prêtes, sans attendre la synthèse)
        playThread = Thread {
            while (running) {
                val chunk: AudioChunk? = try {
                    audioQueue.poll(300, TimeUnit.MILLISECONDS)
                } catch (_: InterruptedException) {
                    null
                }
                if (chunk == null) {
                    if (!running) break else continue
                }
                if (chunk.gen != generation.get()) continue

                playing = true
                try {
                    var offset = 0
                    val step = 4096
                    while (offset < chunk.samples.size && running && chunk.gen == generation.get()) {
                        val n = minOf(step, chunk.samples.size - offset)
                        audioTrack?.write(chunk.samples, offset, n, AudioTrack.WRITE_BLOCKING)
                        offset += n
                    }
                } catch (e: Throwable) {
                    Log.e(TAG, "Erreur lecture audio", e)
                } finally {
                    playing = false
                }
            }
        }.apply {
            isDaemon = true
            start()
        }
    }

    /** Vrai tant qu'il reste du texte à synthétiser ou en cours de synthèse. */
    fun isSpeaking(): Boolean = synthBusy || playing || queue.isNotEmpty() || audioQueue.isNotEmpty()

    fun speak(context: Context, text: String, speakerVoiceIndex: Int) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        if (engine == null) initialize(context)

        if (engine != null) {
            queue.offer(clean to speakerVoiceIndex)
        } else {
            fallbackSpeak(clean, speakerVoiceIndex)
        }
    }

    fun stopSpeech() {
        generation.incrementAndGet()
        queue.clear()
        audioQueue.clear()
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (_: Exception) {
        }
        fallbackStop()
    }

    fun release() {
        running = false
        generation.incrementAndGet()
        queue.clear()
        audioQueue.clear()
        synthThread?.interrupt()
        playThread?.interrupt()
        synthThread = null
        playThread = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {
        }
        audioTrack = null
        try {
            engine?.release()
        } catch (_: Throwable) {
        }
        engine = null
        fallbackRelease()
    }

    // ---------- Voix système (secours) ----------
    private var tts: TextToSpeech? = null
    private var ttsStarting = false
    private var ttsReady = false
    private val ttsPending = mutableListOf<Pair<String, Int>>()
    private val ttsLock = Any()
    private val ttsCounter = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun initFallback(context: Context) {
        val app = context.applicationContext
        synchronized(ttsLock) {
            if (tts != null || ttsStarting) return
            ttsStarting = true
        }
        mainHandler.post {
            tts = TextToSpeech(app) { status -> onFallbackInit(status) }
        }
    }

    private fun onFallbackInit(status: Int) {
        val engineTts = tts
        if (status == TextToSpeech.SUCCESS && engineTts != null) {
            engineTts.setLanguage(Locale.getDefault())
            val toSpeak = synchronized(ttsLock) {
                ttsReady = true
                val copy = ttsPending.toList()
                ttsPending.clear()
                copy
            }
            toSpeak.forEach { (t, v) -> fallbackSpeakNow(t, v) }
        } else {
            Log.e(TAG, "Voix système indisponible (code $status)")
        }
    }

    private fun fallbackSpeak(text: String, voiceIndex: Int) {
        val ready = synchronized(ttsLock) {
            if (!ttsReady) {
                ttsPending.add(text to voiceIndex)
                false
            } else {
                true
            }
        }
        if (ready) fallbackSpeakNow(text, voiceIndex)
    }

    private fun fallbackSpeakNow(text: String, voiceIndex: Int) {
        val engineTts = tts ?: return
        engineTts.setPitch(if (voiceIndex == 0) 1.0f else 0.8f)
        engineTts.speak(text, TextToSpeech.QUEUE_ADD, null, "castpedia-${ttsCounter.incrementAndGet()}")
    }

    private fun fallbackStop() {
        synchronized(ttsLock) { ttsPending.clear() }
        try {
            tts?.stop()
        } catch (_: Exception) {
        }
    }

    private fun fallbackRelease() {
        synchronized(ttsLock) {
            ttsPending.clear()
            ttsReady = false
            ttsStarting = false
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
    }
}
